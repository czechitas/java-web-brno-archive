package cz.czechitas.simpleweb;

import org.springframework.stereotype.*;

@Controller
public class HlavniController {

}
