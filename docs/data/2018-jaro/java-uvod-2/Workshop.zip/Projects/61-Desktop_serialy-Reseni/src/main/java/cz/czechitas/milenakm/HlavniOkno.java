package cz.czechitas.milenakm;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import net.miginfocom.swing.*;
import net.sevecek.util.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labSerie;
    JTextField editSerie;
    JLabel labDil;
    JTextField editDil;
    JButton btnVypocitejDelku;
    JLabel labZbyvajiciCas;
    JTextField editZbyvajiciCas;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;
    MigLayout migLayoutManager;


    public HlavniOkno() {
        initComponents();
    }



    private void priStiskuBtnVypocitejDelku(ActionEvent e) {
        // TODO: Sem napis prevod
    }


    
    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labSerie = new JLabel();
        editSerie = new JTextField();
        labDil = new JLabel();
        editDil = new JTextField();
        btnVypocitejDelku = new JButton();
        labZbyvajiciCas = new JLabel();
        editZbyvajiciCas = new JTextField();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("D\u00e9lka seri\u00e1lu");
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets 0,hidemode 3",
            // columns
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[grow,fill]" +
            "[fill]",
            // rows
            "[grow,fill]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[grow]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());
        LayoutManager layout = this.contentPane.getLayout();
        if (layout instanceof MigLayout) {
            this.migLayoutManager = (MigLayout) layout;
        }

        //---- labSerie ----
        labSerie.setText("Va\u0161e aktu\u00e1ln\u00ed s\u00e9rie:");
        labSerie.setHorizontalAlignment(SwingConstants.TRAILING);
        labSerie.setFont(labSerie.getFont().deriveFont(labSerie.getFont().getSize() + 4f));
        contentPane.add(labSerie, "cell 1 1");

        //---- editSerie ----
        editSerie.setFont(editSerie.getFont().deriveFont(editSerie.getFont().getSize() + 4f));
        editSerie.setColumns(8);
        editSerie.setText("1");
        contentPane.add(editSerie, "cell 2 1 2 1");

        //---- labDil ----
        labDil.setText("Kter\u00fdm d\u00edlem budete za\u010d\u00ednat:");
        labDil.setHorizontalAlignment(SwingConstants.TRAILING);
        labDil.setFont(labDil.getFont().deriveFont(labDil.getFont().getSize() + 4f));
        contentPane.add(labDil, "cell 1 2");

        //---- editDil ----
        editDil.setFont(editDil.getFont().deriveFont(editDil.getFont().getSize() + 4f));
        editDil.setColumns(8);
        editDil.setText("1");
        contentPane.add(editDil, "cell 2 2 2 1");

        //---- btnVypocitejDelku ----
        btnVypocitejDelku.setText("Zjistit zb\u00fdvaj\u00edc\u00ed \u010das");
        btnVypocitejDelku.setFont(btnVypocitejDelku.getFont().deriveFont(btnVypocitejDelku.getFont().getSize() + 4f));
        btnVypocitejDelku.addActionListener(e -> priStiskuBtnVypocitejDelku(e));
        this.getRootPane().setDefaultButton(btnVypocitejDelku);
        contentPane.add(btnVypocitejDelku, "cell 2 3,alignx center,growx 0");

        //---- labZbyvajiciCas ----
        labZbyvajiciCas.setText("Na dosledov\u00e1n\u00ed v\u0161ech d\u00edl\u016f zb\u00fdv\u00e1:");
        labZbyvajiciCas.setHorizontalAlignment(SwingConstants.TRAILING);
        labZbyvajiciCas.setFont(labZbyvajiciCas.getFont().deriveFont(labZbyvajiciCas.getFont().getSize() + 4f));
        contentPane.add(labZbyvajiciCas, "cell 1 4");

        //---- editZbyvajiciCas ----
        editZbyvajiciCas.setFont(editZbyvajiciCas.getFont().deriveFont(editZbyvajiciCas.getFont().getSize() + 4f));
        editZbyvajiciCas.setColumns(8);
        editZbyvajiciCas.setEditable(false);
        contentPane.add(editZbyvajiciCas, "cell 2 4 2 1");
        pack();
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
