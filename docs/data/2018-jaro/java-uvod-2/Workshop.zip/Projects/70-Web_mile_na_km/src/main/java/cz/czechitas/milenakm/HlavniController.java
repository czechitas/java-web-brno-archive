package cz.czechitas.milenakm;

import java.text.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import net.sevecek.util.*;

@Controller
public class HlavniController {

    @RequestMapping(value = "/prevod", consumes = "text/plain", produces = "text/plain")
    @ResponseBody
    public String provedPrevod(@RequestBody String mileText) {

        // TODO: Sem vepiste obsluhu udalosti stisknuti tlacitka

        return "Zatím nic";
    }

}
