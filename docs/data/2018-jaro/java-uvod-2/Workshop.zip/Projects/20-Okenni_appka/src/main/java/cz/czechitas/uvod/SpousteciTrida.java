package cz.czechitas.uvod;

import java.awt.*;
import javax.swing.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        JFrame okno;

        okno = new JFrame("Dnesni datum");
        okno.setVisible(true);
    }

}
