package cz.czechitas.uvod;

import java.awt.*;
import java.time.*;
import java.util.*;
import net.sevecek.util.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        String jmeno;
        int vek;

        jmeno = "Kamil";
        vek = 36;

        System.out.println("Ahoj, zdravi ");
        System.out.println( jmeno );
        System.out.println("Jeho stari je ");
        System.out.println( vek );

        Color zluta;
        Dimension rozmery;
        LocalDate dneska;

        zluta = new Color(255, 255, 0);
        System.out.println(zluta);

        rozmery = new Dimension(400, 300);
        System.out.println(rozmery);

        dneska = LocalDate.of(2018, 6, 23);
        System.out.println("Dnes je ");
        System.out.println(dneska);

        Random generatorNahodnychCisel;
        DoubleFormatter prevodnikCisel;
        generatorNahodnychCisel = new Random();
        prevodnikCisel = new DoubleFormatter("0.##");

        int hozenoNaKostce = generatorNahodnychCisel.nextInt(6) + 1;
        System.out.print("Kostka: ");
        System.out.println(hozenoNaKostce);
    }

}
