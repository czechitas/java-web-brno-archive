package cz.czechitas.kockamyssyr.engine;

import cz.czechitas.kockamyssyr.*;

public class Main {

    public static void main(String[] args) {
        new HlavniProgram().main(args);
    }

}
