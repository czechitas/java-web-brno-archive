package cz.czechitas.kockamyssyr.api;

import javax.swing.*;
import cz.czechitas.kockamyssyr.engine.*;

public class Cat extends FourWayPlayer {

    public Cat(int x, int y) {
        Utils.invokeAndWait(() -> {
            Icon rightImage = new ImageIcon(getClass().getResource(SPRITE_FOLDER + "cat3-right.png"));
            Icon leftImage = new ImageIcon(getClass().getResource(SPRITE_FOLDER + "cat3-left.png"));
            Icon downImage = new ImageIcon(getClass().getResource(SPRITE_FOLDER + "cat3-down.png"));
            Icon upImage = new ImageIcon(getClass().getResource(SPRITE_FOLDER + "cat3-up.png"));
            init(leftImage, rightImage, upImage, downImage, x, y, PlayerType.BAD);
        });
        Gameboard.getInstance().addPlayer(this);
    }

}
