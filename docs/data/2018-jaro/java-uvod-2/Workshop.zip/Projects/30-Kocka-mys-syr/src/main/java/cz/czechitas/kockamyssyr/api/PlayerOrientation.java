package cz.czechitas.kockamyssyr.api;

public enum PlayerOrientation {

    UP,
    RIGHT,
    DOWN,
    LEFT

}
