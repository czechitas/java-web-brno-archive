package cz.czechitas.kockamyssyr.api;

import cz.czechitas.kockamyssyr.engine.*;
import net.sevecek.util.*;
import net.sevecek.util.swing.*;

public class KeyboardBrain implements UniversalBrain {

    private final int keyCodeLeft;
    private final int keyCodeUp;
    private final int keyCodeRight;
    private final int keyCodeDown;
    private Player player;

    public KeyboardBrain() {
        this(KeyCode.UP, KeyCode.LEFT, KeyCode.DOWN, KeyCode.RIGHT);
    }

    public KeyboardBrain(KeyCode keyCodeUp, KeyCode keyCodeLeft, KeyCode keyCodeDown, KeyCode keyCodeRight) {
        this.keyCodeLeft = keyCodeLeft.getKeyEventVkCode();
        this.keyCodeUp = keyCodeUp.getKeyEventVkCode();
        this.keyCodeRight = keyCodeRight.getKeyEventVkCode();
        this.keyCodeDown = keyCodeDown.getKeyEventVkCode();
    }

    @Override
    public void controlPlayer() {
        ThreadUtils.sleep(20L);
        Utils.invokeLater(() -> {
            JKeyboard keyboard = MainWindow.getInstance().getKeyboard();
            if (keyboard.isKeyDown(keyCodeUp)) {
                player.setOrientation(PlayerOrientation.UP);
                player.moveForwardInternal();
            }
            if (keyboard.isKeyDown(keyCodeDown)) {
                player.setOrientation(PlayerOrientation.DOWN);
                player.moveForwardInternal();
            }
            if (keyboard.isKeyDown(keyCodeLeft)) {
                player.setOrientation(PlayerOrientation.LEFT);
                player.moveForwardInternal();
            }
            if (keyboard.isKeyDown(keyCodeRight)) {
                player.setOrientation(PlayerOrientation.RIGHT);
                player.moveForwardInternal();
            }
            player.getSprite().repaint();
        });
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public Player getPlayer() {
        return player;
    }
}
