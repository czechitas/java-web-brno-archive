package cz.czechitas.kockamyssyr.api;

public interface Brain {

    void controlPlayer();

}
