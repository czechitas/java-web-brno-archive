package cz.czechitas.kockamyssyr.api;

import javax.swing.*;
import cz.czechitas.kockamyssyr.engine.*;

public class Cheese extends Player {

    public Cheese(int x, int y) {
        Utils.invokeAndWait(() -> {
            Icon image = new ImageIcon(getClass().getResource(SPRITE_FOLDER + "cheese.png"));
            init(image, x, y, PlayerType.FOOD);
        });
        Gameboard.getInstance().addPlayer(this);
    }

}
