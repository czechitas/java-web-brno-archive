package cz.czechitas.kockamyssyr;

import cz.czechitas.kockamyssyr.api.*;

public class HlavniProgram {

    public void main(String[] args) {
        Mouse sedaMys;
    }

}