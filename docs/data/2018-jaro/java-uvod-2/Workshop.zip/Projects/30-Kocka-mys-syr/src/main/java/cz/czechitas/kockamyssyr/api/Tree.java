package cz.czechitas.kockamyssyr.api;

import javax.swing.*;

import cz.czechitas.kockamyssyr.engine.*;

public class Tree {

    private ImageIcon image;
    private JComponent sprite;

    public Tree(int x, int y) {
        Utils.invokeAndWait(() -> {
            image = new ImageIcon(getClass().getResource(Figure.SPRITE_FOLDER + "tree_shadow_1.png"));
            sprite = new JLabel(image);
            MainWindow.getInstance().add(sprite, "cell " + x + " " + y);
            MainWindow.getInstance().revalidate();
        });
        Gameboard.getInstance().addWall(this);
    }

    public JComponent getSprite() {
        return sprite;
    }
}
