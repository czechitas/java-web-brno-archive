package cz.czechitas.kockamyssyr.api;

import javax.swing.*;
import cz.czechitas.kockamyssyr.engine.*;

public abstract class Figure {

    public static final String SPRITE_FOLDER = "/images/";

    private JLabel sprite;

    protected Figure() {
    }

    protected void init(Icon picture, int x, int y) {
        if (sprite != null) {
            throw new IllegalStateException("Already initialized");
        }
        Utils.invokeAndWait(() -> {
            sprite = new JLabel(picture);
            MainWindow.getInstance().add(sprite, "cell " + x + " " + y);
            MainWindow.getInstance().revalidate();
            MainWindow.getInstance().externFromMigLayout(sprite);
            MainWindow.getInstance().revalidate();
        });
    }

    protected JLabel getSprite() {
        return sprite;
    }

    protected void repaint() {
        sprite.repaint();
    }


}
