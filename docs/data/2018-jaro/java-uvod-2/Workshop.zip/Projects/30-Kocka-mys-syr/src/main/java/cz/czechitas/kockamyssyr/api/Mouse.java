package cz.czechitas.kockamyssyr.api;

import javax.swing.*;
import cz.czechitas.kockamyssyr.engine.*;

public class Mouse extends FourWayPlayer {

    public Mouse(int x, int y) {
        Utils.invokeAndWait(() -> {
            Icon rightImage = new ImageIcon(getClass().getResource(SPRITE_FOLDER + "mouse-right.png"));
            Icon leftImage = new ImageIcon(getClass().getResource(SPRITE_FOLDER + "mouse-left.png"));
            Icon downImage = new ImageIcon(getClass().getResource(SPRITE_FOLDER + "mouse-down.png"));
            Icon upImage = new ImageIcon(getClass().getResource(SPRITE_FOLDER + "mouse-up.png"));
            init(leftImage, rightImage, upImage, downImage, x, y, PlayerType.GOOD);
        });
        Gameboard.getInstance().addPlayer(this);
    }

}
