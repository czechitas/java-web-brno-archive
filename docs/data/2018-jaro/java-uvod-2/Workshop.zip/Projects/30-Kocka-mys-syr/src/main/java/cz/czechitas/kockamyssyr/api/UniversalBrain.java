package cz.czechitas.kockamyssyr.api;

public interface UniversalBrain extends Brain {

    void setPlayer(Player player);

}
