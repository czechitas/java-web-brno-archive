package cz.czechitas.uvod;

import java.awt.*;
import java.time.*;
import java.util.*;

public class SpousteciTrida {

    public static void main(String[] args) {
    
    }

}
