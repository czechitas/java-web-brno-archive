package cz.czechitas.uvod;

import java.awt.*;
import javax.swing.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        JFrame okno;
        JLabel napis;
        Font vetsiFont;

        okno = new JFrame("Dnesni datum");
        okno.setSize(400, 300);
        okno.setLocationRelativeTo(null);
        okno.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        vetsiFont = new Font("Tahoma", Font.PLAIN, 20);

        napis = new JLabel("Dneska je 23. 6. 2018");
        napis.setHorizontalAlignment(SwingConstants.CENTER);
        napis.setFont(vetsiFont);
        okno.add(napis);

        okno.setVisible(true);
    }

}
