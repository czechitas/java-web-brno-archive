package cz.czechitas.tridyaobjekty;

import java.util.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        Random generator = new Random();
        int nahodneCislo = generator.nextInt(30);
        System.out.println(nahodneCislo);
    }

}
