package cz.czechitas.prsi;

public class SpousteciTrida {

    public static void main(String[] args) {
        System.out.println("Sem prijde hra Prsi");
    }

}
