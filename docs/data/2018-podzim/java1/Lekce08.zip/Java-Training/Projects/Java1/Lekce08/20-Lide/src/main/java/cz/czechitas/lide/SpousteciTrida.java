package cz.czechitas.lide;

import java.awt.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        Clovek lektor = new Clovek();
        lektor.setKrestniJmeno("Kamil");
        lektor.setKrestniJmeno("Sevecek");
        lektor.setVek(36);
        lektor.setBarvaOci(new Color(0, 170, 0));

        System.out.println(lektor);

        lektor.zestarniORok();
        System.out.println(lektor);
    }

}
