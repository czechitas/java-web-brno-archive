package cz.czechitas.sport;

public class SpousteciTrida {

    public static void main(String[] args) {
//        Hrac levyHrac = new Hrac("Jana");
//        Hrac pravyHrac = new Hrac("Petra");

/*        PingPong hra = new PingPong(levyHrac, pravyHrac);

        System.out.println(hra);
        hra.pridejBodHraci1();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci1();
        System.out.println(hra);
        hra.pridejBodHraci1();
        System.out.println(hra);
        hra.pridejBodHraci1();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra);
        hra.pridejBodHraci2();
        System.out.println(hra); */
    }

}
