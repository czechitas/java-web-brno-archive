package cz.czechitas.banka;

public class BeznyUcet {

    // TODO: Naprogramujte

}
