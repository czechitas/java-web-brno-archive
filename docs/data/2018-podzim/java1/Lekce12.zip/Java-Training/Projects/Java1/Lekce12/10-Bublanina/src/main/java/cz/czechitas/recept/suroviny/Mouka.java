package cz.czechitas.recept.suroviny;

import cz.czechitas.recept.suroviny.intf.*;

public class Mouka extends AbstractNadobaSeSypkouSurovinou {

    public Mouka(String jmeno) {
        super(jmeno, 1000);
    }
}
