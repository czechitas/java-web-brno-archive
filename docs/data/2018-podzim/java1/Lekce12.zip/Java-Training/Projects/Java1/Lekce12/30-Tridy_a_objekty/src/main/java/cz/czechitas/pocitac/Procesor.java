package cz.czechitas.pocitac;

public class Procesor {

    String vyrobce;
    long rychlost;

    public void vypisInfo() {
        System.out.print("Procesor: " + vyrobce + " " + rychlost + " Hz");
    }

}
