package cz.czechitas.recept.suroviny;

import cz.czechitas.recept.suroviny.intf.*;

public class Vajicka extends AbstractNadobaSKusovouSurovinou {

    public Vajicka(String jmeno) {
        super(jmeno, 10);
    }
}
