package cz.czechitas.recept.suroviny;

import cz.czechitas.recept.suroviny.intf.*;

public class Cukr extends AbstractNadobaSeSypkouSurovinou {

    public Cukr(String jmeno) {
        super(jmeno, 200);
    }
}
