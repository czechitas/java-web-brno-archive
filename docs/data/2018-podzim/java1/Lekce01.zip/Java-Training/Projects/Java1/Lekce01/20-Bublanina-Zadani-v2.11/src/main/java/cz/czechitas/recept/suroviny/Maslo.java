package cz.czechitas.recept.suroviny;

import cz.czechitas.recept.suroviny.intf.*;

public class Maslo extends AbstractNadobaSeSypkouSurovinou {

    public Maslo(String jmeno) {
        super(jmeno, 125);
    }
}
