package net.sevecek.turtle.engine;

import java.awt.*;
import net.sevecek.turtle.*;
import net.sevecek.turtle.engine.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        HlavniProgram prg;
        prg = new HlavniProgram();
        prg.main(args);
    }

}
