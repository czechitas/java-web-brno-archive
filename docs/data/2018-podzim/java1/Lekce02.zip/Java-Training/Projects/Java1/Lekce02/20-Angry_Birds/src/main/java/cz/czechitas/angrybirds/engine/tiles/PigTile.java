package cz.czechitas.angrybirds.engine.tiles;

public class PigTile extends GenericTile {

    public PigTile() {
        super("pig.png");
    }

}
