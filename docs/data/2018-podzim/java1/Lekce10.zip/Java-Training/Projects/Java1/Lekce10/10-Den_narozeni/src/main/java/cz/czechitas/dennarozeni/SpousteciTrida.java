package cz.czechitas.dennarozeni;

import java.time.*;
import java.util.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        Scanner nacitac = new Scanner(System.in);
        System.out.print("Zadejte den narozeni: ");
        int den = nacitac.nextInt();
        System.out.print("Zadejte mesic narozeni: ");
        int mesic = nacitac.nextInt();
        System.out.print("Zadejte rok narozeni: ");
        int rok = nacitac.nextInt();
        
        LocalDate datumNarozeni = LocalDate.of(rok, mesic, den);
        DayOfWeek denNarozeni = datumNarozeni.getDayOfWeek();

        System.out.println("Den narozeni byl " + denNarozeni);
    }

}
