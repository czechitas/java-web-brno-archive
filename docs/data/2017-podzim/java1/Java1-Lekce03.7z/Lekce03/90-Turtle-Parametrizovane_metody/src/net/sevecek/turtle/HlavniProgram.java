package net.sevecek.turtle;

import java.awt.*;
import java.util.*;
import net.sevecek.turtle.engine.*;

public class HlavniProgram {

    Turtle zofka;

    public void run() {
        zofka = new Turtle();
        nakresliRovnoramennyTrojuhelnik(100.0, 90.0);
    }

    private void nakresliRovnoramennyTrojuhelnik(double delkaRamene, double uhelMeziRameny) {
        zofka.move(delkaRamene);
        zofka.penUp();
        zofka.turnLeft(180.0);
        zofka.move(delkaRamene);
        zofka.turnRight(180.0);
        zofka.turnRight(uhelMeziRameny);
        zofka.penDown();
        zofka.move(delkaRamene);
        zofka.turnLeft(180.0 - (180.0-uhelMeziRameny)/2.0);
        zofka.move(vypocitejDelkuTretiStrany(delkaRamene, uhelMeziRameny));
    }

    private double vypocitejDelkuTretiStrany(double velikostRamene, double uhelMeziRameny) {
        double tretiStrana = Math.abs((velikostRamene * Math.sin((uhelMeziRameny * Math.PI / 180) / 2.0)) * 2.0);
        return tretiStrana;
    }

    public void nakresliBarvenouUsecku(double velikostStrany, Color barvaCary) {
        // Zde lze používat proměnnou velikostStrany a barva:
        zofka.setPenColor(barvaCary);
        zofka.move(velikostStrany);
    }

    private Color vygenerujNahodnouBarvu() {
        Random generator;
        int red;
        int green;
        int blue;
        Color nahodnaBarva;

        generator = new Random();
        red = generator.nextInt(256);
        green = generator.nextInt(256);
        blue = generator.nextInt(256);

        nahodnaBarva = new Color(red, green, blue);
        return nahodnaBarva;
    }

}
