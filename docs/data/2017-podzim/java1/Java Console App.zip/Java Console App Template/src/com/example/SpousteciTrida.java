package ${IJ_BASE_PACKAGE};

public class SpousteciTrida {

    public static void main(String[] args) {
        System.out.println("Zdravim, pozemstani! Zavedte me ke svemu vudci");
    }

}
