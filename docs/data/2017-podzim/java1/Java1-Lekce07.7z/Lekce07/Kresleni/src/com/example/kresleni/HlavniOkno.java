package com.example.kresleni;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;
import javax.swing.border.*;
import net.miginfocom.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labInfo;
    JTextField editInfo;
    JLabel labObrazek;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;
    BufferedImage obrazek;
    Color barvaStetce;

    public HlavniOkno() {
        initComponents();
    }

    private void priKliknutiNaLabObrazek(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        editInfo.setText("x=" + x + ", y=" + y);
        nakresliBod(x, y);
    }

    private void nakresliBod(int x, int y) {
        Graphics2D stetec = (Graphics2D) obrazek.getGraphics();
        stetec.setColor(barvaStetce);
        stetec.setStroke(new BasicStroke(10, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        stetec.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        stetec.drawLine(x, y, x, y);
        labObrazek.repaint(x-5, y-5, x+5, y+5);
    }

    private void priOtevreniOkna(WindowEvent e) {
        barvaStetce = new Color(150, 60, 0);
        obrazek = new BufferedImage(1920, 1080, BufferedImage.TYPE_4BYTE_ABGR);
        labObrazek.setIcon(new ImageIcon(obrazek));
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labInfo = new JLabel();
        editInfo = new JTextField();
        labObrazek = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Kresleni");
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                priOtevreniOkna(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets 0,hidemode 3",
            // columns
            "[fill]" +
            "[grow,fill]",
            // rows
            "[]" +
            "[grow,fill]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());

        //---- labInfo ----
        labInfo.setText("text");
        labInfo.setFont(labInfo.getFont().deriveFont(labInfo.getFont().getSize() + 5f));
        contentPane.add(labInfo, "cell 0 0");

        //---- editInfo ----
        editInfo.setFont(editInfo.getFont().deriveFont(editInfo.getFont().getSize() + 8f));
        contentPane.add(editInfo, "cell 1 0");

        //---- labObrazek ----
        labObrazek.setBackground(Color.green);
        labObrazek.setOpaque(true);
        labObrazek.setBorder(new BevelBorder(BevelBorder.LOWERED));
        labObrazek.setFont(labObrazek.getFont().deriveFont(labObrazek.getFont().getSize() + 5f));
        labObrazek.setHorizontalAlignment(SwingConstants.LEFT);
        labObrazek.setVerticalAlignment(SwingConstants.TOP);
        labObrazek.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                priKliknutiNaLabObrazek(e);
            }
        });
        contentPane.add(labObrazek, "cell 0 1 2 1,grow");
        setSize(400, 300);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
