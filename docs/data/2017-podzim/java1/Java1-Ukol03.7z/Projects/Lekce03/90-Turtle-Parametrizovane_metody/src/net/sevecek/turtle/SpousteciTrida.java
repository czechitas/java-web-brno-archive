package net.sevecek.turtle;

import java.awt.*;
import net.sevecek.turtle.engine.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        HlavniProgram prg;
        prg = new HlavniProgram();
        prg.run();
    }

}
