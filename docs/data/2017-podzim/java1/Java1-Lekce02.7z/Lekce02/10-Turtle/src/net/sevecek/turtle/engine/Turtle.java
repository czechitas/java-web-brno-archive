package net.sevecek.turtle.engine;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;

public class Turtle {

    private int x;
    private int y;
    private double angle;
    private Color color;
    private int penWidth;
    private boolean isPenDrawing;
    private BufferedImage turtleSprite;
    private JLabel turtleVisualComponent;

    public Turtle() {
        try {
            Board board = Board.getInstance();
            turtleSprite = ImageIO.read(this.getClass().getClassLoader().getResource("net/sevecek/turtle/images/turtle.png"));
            ImageIcon icon = new ImageIcon(turtleSprite);
            turtleVisualComponent = new JLabel();
            turtleVisualComponent.setIcon(icon);
            turtleVisualComponent.setSize(turtleVisualComponent.getPreferredSize());
            setLocation(board.getSize().width/2, board.getSize().height/2);
            angle = 0;
            penWidth = 3;
            isPenDrawing = true;
            color = new Color(0, 0, 0);
            board.add(turtleVisualComponent);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Integer getX() {
        return x;
    }

    public void setX(Integer newValue) {
        this.x = newValue;
        uiUpdateTurtleLocation();
    }

    private void uiUpdateTurtleLocation() {
        uiUpdateTurtleLocation(x, y);
    }
    
    private void uiUpdateTurtleLocation(int x, int y) {
        turtleVisualComponent.setLocation(x - turtleSprite.getWidth() / 2,
                y - turtleSprite.getHeight() / 2);
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer newValue) {
        this.y = newValue;
        uiUpdateTurtleLocation();
    }

    public void setLocation(Integer newX, Integer newY) {
        this.x = newX;
        this.y = newY;
        uiUpdateTurtleLocation();
    }

    public Color getPenColor() {
        return color;
    }

    public void setPenColor(Color newValue) {
        this.color = newValue;
    }

    public Integer getPenWidth() {
        return penWidth;
    }

    public void setPenWidth(Integer newValue) {
        this.penWidth = newValue;
    }

    private void setAngle(double newAngle) {
        if (newAngle > 360.0) {
            newAngle = newAngle % 360.0;
        }
        if (newAngle < 0.0) {
            newAngle = newAngle % 360.0;
        }
        angle = newAngle;
    }

    public void turnRight(Double byAngle) {
        double originalAngle = angle;
        double newAngle = angle + byAngle;
        rotateTurtleRight(originalAngle, newAngle);
        setAngle(newAngle);
    }

    public void turnLeft(Double byAngle) {
        double originalAngle = angle;
        double newAngle = angle - byAngle;
        rotateTurtleLeft(originalAngle, newAngle);
        setAngle(newAngle);
    }

    private void rotateTurtleRight(double originalAngle, double newAngle) {
        for (double angle = originalAngle; angle < newAngle; angle = angle + 5.0) {
            drawRotatedTurtle(angle);
            try {
                Thread.sleep(5L);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void rotateTurtleLeft(double originalAngle, double newAngle) {
        for (double angle = originalAngle; angle > newAngle; angle = angle - 5.0) {
            drawRotatedTurtle(angle);
            try {
                Thread.sleep(5L);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void drawRotatedTurtle(double angle) {
        AffineTransform tx = AffineTransform.getRotateInstance(angle / 180 * Math.PI, turtleSprite.getWidth()/2, turtleSprite.getHeight()/2);
        AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_BICUBIC);
        BufferedImage newTurtleSprite = op.filter(turtleSprite, null);
        turtleVisualComponent.setIcon(new ImageIcon(newTurtleSprite));
        turtleVisualComponent.setSize(turtleVisualComponent.getPreferredSize());
    }

    public void move(Integer pixels) {
        int newX = (int) (x + Math.cos((angle-90.0)/180.0*Math.PI)*pixels);
        int newY = (int) (y + Math.sin((angle-90.0)/180.0*Math.PI)*pixels);

        if (isPenDrawing) {
            drawLine(pixels);
        }

        uiUpdateTurtleLocation(newX, newY);
        setLocation(newX, newY);
    }

    private void drawLine(int length) {
        BufferedImage painting = Board.getInstance().getPainting();
        Graphics graphics = painting.getGraphics();
        graphics.setColor(color);
        int counter = 0;
        for (double position = 0.0; position < length; position=position+0.5) {
            int newX = (int) (x + Math.cos((angle - 90.0) / 180.0 * Math.PI) * position);
            int newY = (int) (y + Math.sin((angle - 90.0) / 180.0 * Math.PI) * position);
            drawPoint(newX, newY, graphics);
            counter++;
            if (counter > 10) {
                counter = 0;
                uiUpdateTurtleLocation(newX, newY);
            }
            Thread.yield();
        }
    }

    private void drawPoint(int x, int y, Graphics graphics) {
        graphics.fillOval((int) Math.round(x-penWidth/2.0), (int) Math.round(y-penWidth/2.0), penWidth, penWidth);
    }

    public Boolean isPenDrawing() {
        return isPenDrawing;
    }

    public void penUp() {
        this.isPenDrawing = false;
    }

    public void penDown() {
        this.isPenDrawing = true;
    }
}
