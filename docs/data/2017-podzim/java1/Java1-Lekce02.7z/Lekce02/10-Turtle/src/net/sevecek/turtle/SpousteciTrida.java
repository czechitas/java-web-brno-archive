package net.sevecek.turtle;

import java.awt.*;
import net.sevecek.turtle.engine.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        Turtle zofka;
        Color cervenaBarva;

        zofka = new Turtle();
        zofka.setPenWidth(10);
        cervenaBarva = new Color(255, 0, 0);
        zofka.setPenColor(cervenaBarva);
        for (int i=0; i<8; i=i+1) {
            zofka.move(50);
            zofka.turnRight(45.0);
        }
        for (int i=0; i<8; i=i+1) {
            zofka.move(50);
            zofka.turnLeft(45.0);
        }
    }

}
