package net.sevecek.turtle.engine;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.concurrent.*;
import javax.imageio.*;
import javax.swing.*;

public class Board {

    private static Board instance = new Board();
    private long speed;
    private final JLabel visualPaintingComponent;

    public static Board getInstance() {
        return instance;
    }

    //-------------------------------------------------------------------------

    private JFrame window;
    private BufferedImage painting;

    private Board() {
        window = new JFrame("Demo");
        try {
            painting = ImageIO.read(this.getClass().getClassLoader().getResource("net/sevecek/turtle/images/background.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        visualPaintingComponent = new JLabel(new ImageIcon(painting));
        visualPaintingComponent.setHorizontalAlignment(SwingConstants.LEFT);
        visualPaintingComponent.setVerticalAlignment(SwingConstants.TOP);
//        window.add(visualPaintingComponent, BorderLayout.CENTER);
        visualPaintingComponent.setLocation(0, 0);
        visualPaintingComponent.setSize(visualPaintingComponent.getPreferredSize());
        window.setLayout(null);
        window.add(visualPaintingComponent);
        window.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        window.setSize(400, 300);
        window.setLocationRelativeTo(null);
        window.setVisible(true);
    }

    public void add(JLabel sprite) {
        window.add(sprite);
    }

    public void invokeAndWait(Runnable method) {
        try {
            SwingUtilities.invokeAndWait(method);
            Thread.sleep(speed);
        } catch (InterruptedException e) {
            throw new CancellationException();
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    public long getSpeed() {
        return speed;
    }

    public void setSpeed(long newValue) {
        speed = newValue;
    }

    public BufferedImage getPainting() {
        return painting;
    }

    public void repaint(BufferedImage painting) {
        visualPaintingComponent.setIcon(new ImageIcon(painting));
//        visualPaintingComponent.repaint();
    }

    public Dimension getSize() {
        return window.getContentPane().getSize();
    }
}
