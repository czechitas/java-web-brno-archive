package net.sevecek.angrybirds.engine;

public enum BirdType {

    RED,
    MATILDA

}
