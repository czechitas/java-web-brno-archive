package com.example.pingpong;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labMicek;
    JLabel labHrac1;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;
    int deltaX = -10;
    int deltaY = -10;
    Timer casovac;


    public HlavniOkno() {
        initComponents();
    }

    private void priStiskuBtnPohybMicku(ActionEvent e) {
        Point poziceMicku = labMicek.getLocation();
        int x = poziceMicku.x;
        int y = poziceMicku.y;

        x = x + deltaX;
        y = y + deltaY;
        if (x < 0) {
            deltaX = -deltaX;
        }
        if (y < 0) {
            deltaY = -deltaY;
        }
        if (x > (contentPane.getWidth() - labMicek.getWidth())) {
            deltaX = -deltaX;
        }
        if (y > (contentPane.getHeight() - labMicek.getHeight())) {
            deltaY = -deltaY;
        }

        poziceMicku.x = x;
        poziceMicku.y = y;
        labMicek.setLocation(poziceMicku);
    }

    private void priOtevreniOkna(WindowEvent e) {
        casovac = new Timer(50, it -> priStiskuBtnPohybMicku(it));
        casovac.start();
    }

    private void priZaviraniOkna(WindowEvent e) {
        casovac.stop();
    }

    private void priStiskuKlavesy(KeyEvent e) {
        int kodKlavesy = e.getKeyCode();
        if (kodKlavesy == 87) {
            Point souradniceLevyHrac = labHrac1.getLocation();
            int x = souradniceLevyHrac.x;
            int y = souradniceLevyHrac.y;
            y = y - 10;
            souradniceLevyHrac.x = x;
            souradniceLevyHrac.y = y;
            labHrac1.setLocation(souradniceLevyHrac);
        }
        if (kodKlavesy == 83) {
            Point souradniceLevyHrac = labHrac1.getLocation();
            int x = souradniceLevyHrac.x;
            int y = souradniceLevyHrac.y;
            y = y + 10;
            souradniceLevyHrac.x = x;
            souradniceLevyHrac.y = y;
            labHrac1.setLocation(souradniceLevyHrac);
        }
    }

    private boolean detekujKolizi(JLabel label1, JLabel label2) {
        Point souradniceLevyHrac = label1.getLocation();
        int ax = souradniceLevyHrac.x;
        int ay = souradniceLevyHrac.y;

        int bx = ax + label1.getWidth();
        int by = ay + label1.getHeight();

        Point souradnicePravyHrac = label2.getLocation();
        int cx = souradnicePravyHrac.x;
        int cy = souradnicePravyHrac.y;

        int dx = cx + label2.getWidth();
        int dy = cy + label2.getHeight();

        if (ax <= dx && ay <= dy
                && cx <= bx && cy <= by) {
            return true;
        } else {
            return false;
        }
    }


    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labMicek = new JLabel();
        labHrac1 = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("PingPong");
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                priZaviraniOkna(e);
            }
            @Override
            public void windowOpened(WindowEvent e) {
                priOtevreniOkna(e);
            }
        });
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                priStiskuKlavesy(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(null);
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());

        //---- labMicek ----
        labMicek.setIcon(new ImageIcon(getClass().getResource("/com/example/pingpong/micek.png")));
        contentPane.add(labMicek);
        labMicek.setBounds(new Rectangle(new Point(250, 80), labMicek.getPreferredSize()));

        //---- labHrac1 ----
        labHrac1.setIcon(new ImageIcon(getClass().getResource("/com/example/pingpong/levy-hrac.png")));
        contentPane.add(labHrac1);
        labHrac1.setBounds(new Rectangle(new Point(65, 105), labHrac1.getPreferredSize()));

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(400, 300);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
