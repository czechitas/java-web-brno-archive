package com.example.r2d2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labRobot;
    JLabel labZed1;
    JLabel labZed2;
    JLabel labZed3;
    JLabel labZed4;
    JLabel labZed5;
    JLabel labZed6;
    JLabel labZed7;
    JLabel labZed8;
    JLabel labZed9;
    JLabel labZed10;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;

    public HlavniOkno() {
        initComponents();
    }


    private boolean detekujKolizi(JLabel label1, JLabel label2) {
        Point souradniceLevyHrac = label1.getLocation();
        int ax = souradniceLevyHrac.x;
        int ay = souradniceLevyHrac.y;

        int bx = ax + label1.getWidth();
        int by = ay + label1.getHeight();

        Point souradnicePravyHrac = label2.getLocation();
        int cx = souradnicePravyHrac.x;
        int cy = souradnicePravyHrac.y;

        int dx = cx + label2.getWidth();
        int dy = cy + label2.getHeight();

        if (ax <= dx && ay <= dy
                && cx <= bx && cy <= by) {
            return true;
        } else {
            return false;
        }
    }

    private void priStiskuKlavesy(KeyEvent e) {
        int kodKlavesy = e.getKeyCode();
        if (kodKlavesy == 39) {
            labRobot.setIcon(new ImageIcon(getClass().getResource(
                    "/com/example/r2d2/r2d2-vpravo.png")));
        } else if (kodKlavesy == 37) {
            labRobot.setIcon(new ImageIcon(getClass().getResource(
                    "/com/example/r2d2/r2d2-vlevo.png")));
        }
    }


    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labRobot = new JLabel();
        labZed1 = new JLabel();
        labZed2 = new JLabel();
        labZed3 = new JLabel();
        labZed4 = new JLabel();
        labZed5 = new JLabel();
        labZed6 = new JLabel();
        labZed7 = new JLabel();
        labZed8 = new JLabel();
        labZed9 = new JLabel();
        labZed10 = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("R2D2");
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                priStiskuKlavesy(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(null);
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());

        //---- labRobot ----
        labRobot.setIcon(new ImageIcon(getClass().getResource("/com/example/r2d2/r2d2-vlevo.png")));
        contentPane.add(labRobot);
        labRobot.setBounds(new Rectangle(new Point(150, 130), labRobot.getPreferredSize()));

        //---- labZed1 ----
        labZed1.setBackground(Color.blue);
        labZed1.setOpaque(true);
        contentPane.add(labZed1);
        labZed1.setBounds(90, 20, 145, 35);

        //---- labZed2 ----
        labZed2.setBackground(Color.blue);
        labZed2.setOpaque(true);
        contentPane.add(labZed2);
        labZed2.setBounds(235, 20, 30, 120);

        //---- labZed3 ----
        labZed3.setBackground(Color.blue);
        labZed3.setOpaque(true);
        contentPane.add(labZed3);
        labZed3.setBounds(100, 150, 30, 120);

        //---- labZed4 ----
        labZed4.setBackground(Color.blue);
        labZed4.setOpaque(true);
        contentPane.add(labZed4);
        labZed4.setBounds(5, 150, 95, 30);

        //---- labZed5 ----
        labZed5.setBackground(Color.blue);
        labZed5.setOpaque(true);
        contentPane.add(labZed5);
        labZed5.setBounds(100, 270, 215, 30);

        //---- labZed6 ----
        labZed6.setBackground(Color.blue);
        labZed6.setOpaque(true);
        contentPane.add(labZed6);
        labZed6.setBounds(265, 110, 55, 30);

        //---- labZed7 ----
        labZed7.setBackground(Color.blue);
        labZed7.setOpaque(true);
        contentPane.add(labZed7);
        labZed7.setBounds(320, 20, 30, 120);

        //---- labZed8 ----
        labZed8.setBackground(Color.blue);
        labZed8.setOpaque(true);
        contentPane.add(labZed8);
        labZed8.setBounds(285, 240, 215, 30);

        //---- labZed9 ----
        labZed9.setBackground(Color.blue);
        labZed9.setOpaque(true);
        contentPane.add(labZed9);
        labZed9.setBounds(350, 20, 165, 30);

        //---- labZed10 ----
        labZed10.setBackground(Color.blue);
        labZed10.setOpaque(true);
        contentPane.add(labZed10);
        labZed10.setBounds(465, 130, 35, 110);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(400, 300);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
