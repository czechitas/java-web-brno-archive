import javax.swing.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        JFrame okno = new JFrame("Hlavni okno");
        okno.setVisible(true);
    }


}