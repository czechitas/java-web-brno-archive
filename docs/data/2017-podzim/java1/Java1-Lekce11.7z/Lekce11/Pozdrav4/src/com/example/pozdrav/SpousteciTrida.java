package com.example.pozdrav;

public class SpousteciTrida {

    public static void main(String[] args) {
        System.out.println(args[0]);
        HlavniOkno okno = new HlavniOkno();
        okno.setVisible(true);
    }

}
