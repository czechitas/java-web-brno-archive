package cz.czechitas.recept.suroviny.intf;

public interface NadobaSeSypkouSurovinou {

    String getJmeno();

    int getHmotnost();

    void setHmotnost(int hmotnost);
}
