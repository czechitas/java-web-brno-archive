package com.example.pingpong;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import net.sevecek.util.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labMicek;
    JLabel labHracLevy;
    JLabel labHracPravy;
    JLabel labLevyHracScore;
    JLabel labPravyHracScore;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    private JPanel contentPane;
    private int deltaX = SPEED_INIT;
    private int deltaY = SPEED_INIT;
    private Timer casovac;
    private Timer pauzovac;
    private JKeyboard klavesnice;
    Boolean hrajeSe;
    int pravyHracScore = 0;
    int levyHracScore = 0;
    private static final int SPEED_INIT = 10;        // deltaX = deltaY
    private static final int LEVY_HRAC_NAHORU = 87;  // písmeno W
    private static final int LEVY_HRAC_DOLU = 83;    // písmeno S
    private static final int PRAVY_HRAC_NAHORU = 38; // šipka nahoru
    private static final int PRAVY_HRAC_DOLU = 40;   // šipka dolu
    private static final int MEZERA = 32;            // mezera

    public HlavniOkno() {
        initComponents();
    }

    private void priTiknutiCasovace(ActionEvent e) {
        pohybHrace();
        pohybMicku();
    }

    private void pohybMicku() {
        Point poziceMicku = labMicek.getLocation();
        int x = poziceMicku.x;
        int y = poziceMicku.y;

        x = x + deltaX;
        y = y + deltaY;

        poziceMicku.x = x;
        poziceMicku.y = y;
        labMicek.setLocation(poziceMicku);

        if  (detekceKolize(labHracLevy, labMicek)) {
            if (deltaX < 0) {
                deltaX = -deltaX;
            }
            return;
        }

        if  (detekceKolize(labHracPravy, labMicek)) {
            if (deltaX > 0) {
                deltaX = -deltaX;
            }
            return;
        }

        if (x < 0) {
            pravyHracScore = pravyHracScore + 1;
            labPravyHracScore.setText(Integer.toString(pravyHracScore));
            startHry();
            return;
        }

        if (x + labMicek.getWidth() >= contentPane.getWidth()) {
            levyHracScore = levyHracScore + 1;
            labLevyHracScore.setText(Integer.toString(levyHracScore));
            startHry();
            return;
        }

        if (y < 0) {
             y = -y;
             deltaY = -deltaY;
         }

        if ((y + labMicek.getHeight()) >= contentPane.getHeight()) {
             deltaY = -deltaY;
         }
    }

    private void priOtevreniOkna(WindowEvent e) {
        startHry();
        casovac = new Timer(50, it -> priTiknutiCasovace(it)); // it používáme, protože "e" už v metodě máme
        casovac.start();

        klavesnice = new JKeyboard();

        hrajeSe = true;
        labLevyHracScore.setText(Integer.toString(levyHracScore));
        labPravyHracScore.setText(Integer.toString(pravyHracScore));
    }

    private void startHry () {
        labMicek.setLocation(contentPane.getWidth()/2, contentPane.getHeight()/2);
    }

    private void priZavreniOkna(WindowEvent e) {
        casovac.stop();
    }

    public static final int DELTA = 15;

    private void pohybHrace() {
        Point souradnicePlocha = this.getLocation();

        // W - levy hrac jde nahoru
        if (klavesnice.isKeyDown(KeyEvent.VK_W)) {
            Point souradniceLevyHrac = labHracLevy.getLocation();
            int x = souradniceLevyHrac.x;
            int y = souradniceLevyHrac.y;
            x = x;
            y = y - DELTA;
            souradniceLevyHrac.x = x;
            souradniceLevyHrac.y = y;
            if ( y < 0 ) {
               return;
            } else {
                labHracLevy.setLocation(x, y);
            }
        }
        
        // S - levy hrac jde dolu
        if (klavesnice.isKeyDown(KeyEvent.VK_S)) {
            Point souradniceLevyHrac = labHracLevy.getLocation();
            int x = souradniceLevyHrac.x;
            int y = souradniceLevyHrac.y;
            x = x;
            y = y + DELTA;
            souradniceLevyHrac.x = x;
            souradniceLevyHrac.y = y;
            if ( (y + labHracLevy.getHeight()) < contentPane.getHeight() ) {
                labHracLevy.setLocation(x, y);
            }
        }

        // šipka nahoru - pravý hráč jede nahoru
        if (klavesnice.isKeyDown(KeyEvent.VK_UP)) {
            Point souradnicePravyHrac = labHracPravy.getLocation();
            int x = souradnicePravyHrac.x;
            int y = souradnicePravyHrac.y;
            x = x;
            y = y - DELTA;
            souradnicePravyHrac.x = x;
            souradnicePravyHrac.y = y;
            if ( y < 0 ) {
                return;
            } else {
                labHracPravy.setLocation(x, y);
            }
        }

        // šipka dolů - pravý hráč jede dolu
        if (klavesnice.isKeyDown(KeyEvent.VK_DOWN)) {
            Point souradnicePravyHrac = labHracPravy.getLocation();
            int x = souradnicePravyHrac.x;
            int y = souradnicePravyHrac.y;
            x = x;
            y = y + DELTA;
            souradnicePravyHrac.x = x;
            souradnicePravyHrac.y = y;
            if ( (y + labHracPravy.getHeight()) < contentPane.getHeight() ) {
                labHracPravy.setLocation(x, y);
            }
        }

        // při stisku mezery se hra zastaví a spustí
        if (klavesnice.isKeyDown(KeyEvent.VK_SPACE)) {
            if (hrajeSe) {
                casovac.stop();
                hrajeSe = false;
            } else {
                casovac.start();
                hrajeSe = true;
            }
        }
    }

    private boolean detekceKolize(JLabel label1, JLabel label2) {
        Point souradniceLabel1 = label1.getLocation();
        int ax = souradniceLabel1.x;
        int ay = souradniceLabel1.y;

        int bx = ax + label1.getWidth();
        int by = ay + label1.getHeight();

        Point souradniceLabel2 = label2.getLocation();
        int cx = souradniceLabel2.x;
        int cy = souradniceLabel2.y;

        int dx = cx + label2.getWidth();
        int dy = cy + label2.getHeight();

        if (ax <= dx && ay <= dy && cx <= bx && cy <= by ) {
           return true;
        }

        return false;
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labMicek = new JLabel();
        labHracLevy = new JLabel();
        labHracPravy = new JLabel();
        labLevyHracScore = new JLabel();
        labPravyHracScore = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("PingPong");
        setResizable(false);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                priZavreniOkna(e);
            }
            @Override
            public void windowOpened(WindowEvent e) {
                priOtevreniOkna(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(null);
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());

        //---- labMicek ----
        labMicek.setIcon(new ImageIcon(getClass().getResource("/com/example/pingpong/micek.png")));
        contentPane.add(labMicek);
        labMicek.setBounds(new Rectangle(new Point(550, 355), labMicek.getPreferredSize()));

        //---- labHracLevy ----
        labHracLevy.setIcon(new ImageIcon(getClass().getResource("/com/example/pingpong/levy-hrac.png")));
        contentPane.add(labHracLevy);
        labHracLevy.setBounds(new Rectangle(new Point(0, 205), labHracLevy.getPreferredSize()));

        //---- labHracPravy ----
        labHracPravy.setIcon(new ImageIcon(getClass().getResource("/com/example/pingpong/pravy-hrac.png")));
        labHracPravy.setMaximumSize(new Dimension(0, 128));
        labHracPravy.setMinimumSize(new Dimension(0, 128));
        contentPane.add(labHracPravy);
        labHracPravy.setBounds(new Rectangle(new Point(750, 450), labHracPravy.getPreferredSize()));

        //---- labLevyHracScore ----
        labLevyHracScore.setText("0");
        labLevyHracScore.setAlignmentX(0.5F);
        labLevyHracScore.setFocusable(false);
        labLevyHracScore.setHorizontalAlignment(SwingConstants.CENTER);
        labLevyHracScore.setFont(labLevyHracScore.getFont().deriveFont(labLevyHracScore.getFont().getSize() + 20f));
        contentPane.add(labLevyHracScore);
        labLevyHracScore.setBounds(105, 10, 20, 35);

        //---- labPravyHracScore ----
        labPravyHracScore.setText("0");
        labPravyHracScore.setAlignmentX(0.5F);
        labPravyHracScore.setFocusable(false);
        labPravyHracScore.setHorizontalAlignment(SwingConstants.CENTER);
        labPravyHracScore.setFont(labPravyHracScore.getFont().deriveFont(labPravyHracScore.getFont().getSize() + 20f));
        contentPane.add(labPravyHracScore);
        labPravyHracScore.setBounds(650, 10, 20, 35);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(795, 650);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
