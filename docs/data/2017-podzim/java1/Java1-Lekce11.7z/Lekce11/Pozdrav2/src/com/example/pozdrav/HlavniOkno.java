package com.example.pozdrav;

import java.awt.*;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    JButton btnPozdravit;
    Container contentPane;

    // Constructor
    public HlavniOkno() {
        initComponents();
    }

    public void initComponents() {
        contentPane = this.getContentPane();

        btnPozdravit = new JButton("Pozdravit");
        contentPane.add(btnPozdravit);
    }

}
