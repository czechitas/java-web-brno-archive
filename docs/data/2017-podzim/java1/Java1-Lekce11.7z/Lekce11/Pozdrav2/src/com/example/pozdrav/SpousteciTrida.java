package com.example.pozdrav;

import javax.swing.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        HlavniOkno okno = new HlavniOkno();
        okno.setVisible(true);
    }

}
