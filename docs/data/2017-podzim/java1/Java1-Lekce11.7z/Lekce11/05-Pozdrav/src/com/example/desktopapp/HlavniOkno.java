package com.example.desktopapp;

import java.awt.*;
import javax.swing.*;
import net.miginfocom.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labJmeno;
    JTextField editJmeno;
    JButton btnPozdravit;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;

    public HlavniOkno() {
        initComponents();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labJmeno = new JLabel();
        editJmeno = new JTextField();
        btnPozdravit = new JButton();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Pozdrav");
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets 0,hidemode 3",
            // columns
            "[fill]" +
            "[fill]" +
            "[grow,fill]" +
            "[fill]" +
            "[fill]",
            // rows
            "[grow,fill]" +
            "[]" +
            "[grow]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());

        //---- labJmeno ----
        labJmeno.setText("Zadejte svoje jm\u00e9no:");
        contentPane.add(labJmeno, "cell 1 1");
        contentPane.add(editJmeno, "cell 2 1");

        //---- btnPozdravit ----
        btnPozdravit.setText("Pozdravit");
        contentPane.add(btnPozdravit, "cell 3 1");
        setSize(400, 111);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
