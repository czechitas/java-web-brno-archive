package com.example.soubor;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        try {
            Path soubor = Paths.get("score.txt");
            List<String> radkySouboru = Files.readAllLines(soubor);

            System.out.println(radkySouboru);

            Files.write(soubor, radkySouboru);
        } catch (IOException chyba) {
//            throw new ApplicationPublicException(chyba, "Nepodařilo se nahrát soubor");
            throw new RuntimeException("Nepodařilo se nahrát soubor", chyba);
        }
    }

}
