package net.sevecek.turtle;

import java.awt.*;
import java.util.*;
import net.sevecek.turtle.engine.*;

public class HlavniProgram {

    Turtle zofka;

    public void run() {
        zofka = new Turtle();
        nakresliMasinku(160.0, 3, vygenerujNahodnouBarvu());
        nakresliMezeru(80.0);
        nakresliSnehulaka(200.0, 3, vygenerujNahodnouBarvu());
        nakresliMezeru(140.0);
        nakresliZmrzlinuUpgread(90.0, 150.0, 6, vygenerujNahodnouBarvu());
        nakresliMezeru(80.0);
        nakresliZmrzlinu(150.0, 65.0, 6, vygenerujNahodnouBarvu());
        nakresliMezeru(80);

    }

    private void nakresliMasinku(double vyskaMasinky, int penWidth, Color barva) {
        double delkaMotoru = vyskaMasinky * 0.75;
        double vyskaKabiny = delkaMotoru;
        double prumerVelkehoKola = vyskaMasinky / 4;
        double prumerMalehoKola = vyskaMasinky / 8;
        zofka.setPenColor(barva);
        zofka.setPenWidth(penWidth);
        zofka.turnRight(135.0);
        nakresliRovnoramennyTrojuhelnik(delkaMotoru / 2, 90.0);
        zofka.turnLeft(45.0);
        zofka.move(delkaMotoru / 2);
        zofka.turnLeft(90.0);
        zofka.move(delkaMotoru / 6);
        nakresliObdelnik(delkaMotoru, delkaMotoru * 0.5);
        nakresliObdelnik(vyskaMasinky / 2, vyskaKabiny);
        zofka.turnRight(180.0);
        nakresliKruh(prumerVelkehoKola);
        zofka.turnRight(90.0);
        zofka.move(prumerMalehoKola);
        zofka.turnLeft(90.0);
        zofka.penUp();
        zofka.move(prumerMalehoKola + penWidth);
        zofka.penDown();
        nakresliKruh(prumerMalehoKola);
        zofka.turnRight(90.0);
        zofka.penUp();
        zofka.move(prumerMalehoKola / 2);
        zofka.turnLeft(90.0);
        zofka.penDown();
        nakresliKruh(prumerMalehoKola);
        zofka.penUp();
        zofka.turnLeft(90.0);
        zofka.move(delkaMotoru + vyskaMasinky / 2);
        zofka.penDown();
        zofka.turnLeft(90.0);
    }

    private void nakresliSnehulaka(double vyskaSnehulaka, int penWidth, Color barva) {
        zofka.setPenColor(barva);
        zofka.setPenWidth(penWidth);
        double vyskaKoule1 = (vyskaSnehulaka / 9) * 4;
        double vyskaKoule2 = (vyskaSnehulaka / 9) * 3;
        double vyskaKoule3 = (vyskaSnehulaka / 9) * 2;
        double vyskaKoule4 = vyskaSnehulaka / 9 * 0.5;
        zofka.turnLeft(90.0);
        nakresliKruh(vyskaKoule1 / 2);
        nakresliKruh(vyskaKoule2 / 2);
        nakresliKruh(vyskaKoule3 / 2);
        zofka.turnLeft(90.0);
        zofka.penUp();
        zofka.move(vyskaKoule3 + 0.5 * vyskaKoule2);
        zofka.turnRight(90.0);
        zofka.move(30.0 + penWidth);
        zofka.turnLeft(90.0);
        zofka.penDown();
        nakresliKruh(vyskaKoule4);
        zofka.turnLeft(90.0);
        zofka.penUp();
        zofka.move(vyskaKoule4 + vyskaKoule2 + 4 * penWidth);
        zofka.penDown();
        zofka.turnLeft(90.0);
        nakresliKruh(vyskaKoule4);
        zofka.turnLeft(180.0);
        zofka.penUp();
        zofka.move(vyskaKoule2 / 2 + vyskaKoule1);
        zofka.turnLeft(180.0);
        zofka.penDown();
    }

    private void nakresliZmrzlinu(double vyskaKornoutu, double sirkaKornoutu, int penWidth, Color barva) {
        double delkaRamene = vypocitejStranuCPravouhlyTrojuhelnik(vyskaKornoutu, sirkaKornoutu / 2);
        double uhelBeta = 90 - vypocitejUhelAlfa(vyskaKornoutu, delkaRamene);
        zofka.setPenWidth(penWidth);
        zofka.setPenColor(barva);
        zofka.turnRight(180.0);
        nakresliRovnoramennyTrojuhelnik(delkaRamene, 2 * uhelBeta);
        zofka.turnRight(180.0);
        zofka.penUp();
        zofka.move((double) penWidth);
        zofka.penDown();
        nakresliKruh(sirkaKornoutu / 2);
    }

    private void nakresliZmrzlinuUpgread(double vyskaKornoutu, double sirkaKornoutu, int penWidth, Color barva) {
        double delkaRamene = vypocitejStranuCPravouhlyTrojuhelnik(vyskaKornoutu, sirkaKornoutu / 2);
        double uhelBeta = 90 - vypocitejUhelAlfa(vyskaKornoutu, delkaRamene);
        System.out.println(delkaRamene);
        System.out.println(uhelBeta);
        zofka.setPenWidth(penWidth);
        zofka.setPenColor(barva);
        zofka.turnRight(180.0);
        nakresliRovnoramennyTrojuhelnik(delkaRamene, 2 * uhelBeta);
        zofka.turnRight(180.0);
        nakresliPulKruh(sirkaKornoutu / 2);
    }

    private double vyskaRovnoramennehoTrojuhelniku(double delkaRamene, double uhelMeziRameny) {
        double uhelAlfa = (180 - uhelMeziRameny) / 2;
        uhelAlfa = Math.toRadians(uhelAlfa);
        return delkaRamene * Math.sin(uhelAlfa);
    }

    private void nakresliRovnoramennyTrojuhelnik(double delkaRamene, double uhelMeziRameny) {
        double delkaTretiStrany;
        delkaTretiStrany = vypocitejDelkuTretiStrany(delkaRamene, uhelMeziRameny);
        double uhelRamenoZakladna = (180.0 - uhelMeziRameny) / 2;
        zofka.turnRight(90.0 - uhelRamenoZakladna);
        zofka.move(delkaRamene);
        zofka.turnRight(180.0 - uhelMeziRameny);
        zofka.move(delkaRamene);
        zofka.turnRight(180.0 - uhelRamenoZakladna);
        zofka.move(delkaTretiStrany);
        zofka.turnRight(180.0);
        zofka.penUp();
        zofka.move(delkaTretiStrany);
        zofka.turnLeft(90.0);
        zofka.penDown();
    }

    private void nakresliRovnostrannyTrojuhelnik(double delkaRamene) {
        zofka.turnRight(90.0 - 60.0);
        zofka.move(delkaRamene);
        zofka.turnRight(180.0 - 60.0);
        zofka.move(delkaRamene);
        zofka.turnRight(180.0 - 60.0);
        zofka.move(delkaRamene);
        zofka.turnRight(180.0);
        zofka.penUp();
        zofka.move(delkaRamene);
        zofka.turnLeft(90.0);
        zofka.penDown();
    }

    private void nakresliPravouhlyTrojuhelnik(double delkaRameneA, double delkaRameneB) {
        double delkaRameneC = vypocitejStranuCPravouhlyTrojuhelnik(delkaRameneA, delkaRameneB);
        zofka.move(delkaRameneB);
        zofka.turnRight(180.0 - vypocitejUhelAlfa(delkaRameneA, delkaRameneC));
        zofka.move(delkaRameneC);
        zofka.turnRight(90.0 + vypocitejUhelAlfa(delkaRameneA, delkaRameneC));
        zofka.move(delkaRameneA);
        zofka.turnRight(180.0);
        zofka.penUp();
        zofka.move(delkaRameneA);
        zofka.turnLeft(90.0);
        zofka.penDown();

    }

    private double vypocitejStranuCPravouhlyTrojuhelnik(double delkaRameneA, double delkaRameneB) {
        return Math.sqrt(Math.pow(delkaRameneA, 2) + Math.pow(delkaRameneB, 2));
    }

    private void nakresliKruh(double polomer) {
        for (int i = 0; i < 36; i++) {
            zofka.turnRight(10.00);
            zofka.move((2 * Math.PI * polomer * 10.0 / 360));
        }
        zofka.turnRight(90.0);
        zofka.penUp();
        zofka.move(polomer * 2);
        zofka.turnLeft(90.0);
        zofka.penDown();
    }

    private void nakresliPulKruh(double polomer) {
        for (int i = 0; i < 18; i++) {
            zofka.turnRight(10.00);
            zofka.move((2 * Math.PI * polomer * 10.0 / 360));
        }
        zofka.turnRight(180.0);
    }

    private void nakresliCtverec(double delkaStrany) {
        for (int i = 0; i < 4; i++) {
            zofka.move(delkaStrany);
            zofka.turnRight(90.0);
        }
        zofka.turnRight(90.0);
        zofka.penUp();
        zofka.move(delkaStrany);
        zofka.turnLeft(90.0);
        zofka.penDown();
    }

    private void nakresliObdelnik(double delkaStranyA, double delkaStranyB) {
        for (int i = 0; i < 2; i++) {
            zofka.move(delkaStranyB);
            zofka.turnRight(90.0);
            zofka.move(delkaStranyA);
            zofka.turnRight(90.0);
        }
        zofka.turnRight(90.0);
        zofka.penUp();
        zofka.move(delkaStranyA);
        zofka.turnLeft(90.0);
        zofka.penDown();
    }

    private void nakresliMezeru(double velikostMezery) {
        zofka.penUp();
        zofka.turnRight(90.0);
        zofka.move(velikostMezery);
        zofka.turnLeft(90.0);
        zofka.penDown();
    }

    private double vypocitejUhelAlfa(double delkaRameneA, double delkaRameneC) {
        return Math.toDegrees(Math.asin(delkaRameneA / delkaRameneC));
    }

    private double vypocitejDelkuTretiStrany(double velikostRamene, double uhelMeziRameny) {
        double tretiStrana = Math.abs((velikostRamene * Math.sin((uhelMeziRameny * Math.PI / 180) / 2.0)) * 2.0);
        return tretiStrana;
    }

    public void nakresliBarvenouUsecku(double velikostStrany, Color barvaCary) {
        // Zde lze používat proměnnou velikostStrany a barva:
        zofka.setPenColor(barvaCary);
        zofka.move(velikostStrany);
    }

    private Color vygenerujNahodnouBarvu() {
        Random generator;
        int red;
        int green;
        int blue;
        Color nahodnaBarva;

        generator = new Random();
        red = generator.nextInt(256);
        green = generator.nextInt(256);
        blue = generator.nextInt(256);

        nahodnaBarva = new Color(red, green, blue);
        return nahodnaBarva;
    }

}
