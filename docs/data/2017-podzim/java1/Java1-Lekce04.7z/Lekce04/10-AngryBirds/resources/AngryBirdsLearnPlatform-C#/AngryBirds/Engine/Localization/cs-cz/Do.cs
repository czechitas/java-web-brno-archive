namespace AngryBirds.Engine.Localization
{
    public enum Do
    {
        Leva = Direction.Left,
        Prava = Direction.Right,
    }
}