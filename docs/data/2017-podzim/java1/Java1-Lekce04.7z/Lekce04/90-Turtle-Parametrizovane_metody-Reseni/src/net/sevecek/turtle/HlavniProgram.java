package net.sevecek.turtle;

import java.awt.*;
import java.util.*;
import net.sevecek.turtle.engine.*;

public class HlavniProgram {

    Turtle zofka;

    public void run() {
        zofka = new Turtle();

//        zofka.setLocation(200,300);
//        nakresliRovnoramennyTrojuhelnik(100.0, 90.0);
//
//        zofka.setLocation(350,300);
//        nakresliCtverec(75.0);
//
//        zofka.setLocation(500,300);
//        nakresliObdelnik(75.0, 100.0);
//
//        zofka.setLocation(200, 400);
//        nakresliKolecko(75.0);

        nakresliZmrzlinu(200.0, 45.0);
//        nakresliSnehulaka(400.0);
//        nakresliMasinku();
    }

    private void nakresliRovnoramennyTrojuhelnik(double delkaRamene, double uhelMeziRameny) {
        double tretiStrana;
        double tretiUhel;

        zofka.move(delkaRamene);
        zofka.penUp();
        zofka.turnLeft(180.0);
        zofka.move(delkaRamene);
        zofka.turnLeft(180.0 - uhelMeziRameny);
        zofka.penDown();
        zofka.move(delkaRamene);
        tretiUhel = 180.0 - (180.0 - uhelMeziRameny) / 2.0;
        zofka.turnLeft(tretiUhel);

        tretiStrana = vypocitejDelkuTretiStrany(delkaRamene, uhelMeziRameny);
        zofka.move(tretiStrana);

        zofka.penUp();
        zofka.turnLeft(tretiUhel);
        zofka.move(delkaRamene);
        zofka.turnLeft(180.0);
        zofka.penDown();
    }

    private double vypocitejDelkuTretiStrany(double velikostRamene, double uhelMeziRameny) {
        double tretiStrana = Math.abs((velikostRamene * Math.sin((uhelMeziRameny * Math.PI / 180) / 2.0)) * 2.0);
        return tretiStrana;
    }

    public void nakresliBarvenouUsecku(double velikostStrany, Color barvaCary) {
        // Zde lze používat proměnnou velikostStrany a barva:
        zofka.setPenColor(barvaCary);
        zofka.move(velikostStrany);
    }

    private Color vygenerujNahodnouBarvu() {
        Random generator;
        int red;
        int green;
        int blue;
        Color nahodnaBarva;

        generator = new Random();
        red = generator.nextInt(256);
        green = generator.nextInt(256);
        blue = generator.nextInt(256);

        nahodnaBarva = new Color(red, green, blue);
        return nahodnaBarva;
    }

    private void nakresliCtverec(double delkaRamene) {
        nakresliObdelnik(delkaRamene, delkaRamene);
    }

    private void nakresliObdelnik(double delkaRameneA, double delkaRameneB) {
        for (int i = 0; i < 2; i++) {
            zofka.move(delkaRameneA);
            zofka.turnRight(90.0);
            zofka.move(delkaRameneB);
            zofka.turnRight(90.0);
        }
    }

    private void nakresliKolecko(double prumer) {
        nakresliPulKolecko(prumer);
        nakresliPulKolecko(prumer);
    }

    private void nakresliPulKolecko(double prumer) {
        int kolikrat = 40;
        double uhel = 360.0 / kolikrat;
        double posun = Math.PI * prumer / kolikrat;
        zofka.penDown();
        for (int i = 0; i < kolikrat / 2; i++) {
            zofka.move(posun);
            zofka.turnRight(uhel);
        }
    }

    private void nakresliZmrzlinu(double vyskaKornoutu, double uhelKornoutu) {
        zofka.turnLeft(uhelKornoutu / 2.0);
        nakresliRovnoramennyTrojuhelnik(vyskaKornoutu, uhelKornoutu);

        zofka.penUp();
        zofka.move(vyskaKornoutu);
        zofka.turnRight(uhelKornoutu / 2.0);

        double prumer;
        prumer = vypocitejDelkuTretiStrany(vyskaKornoutu, uhelKornoutu);
        nakresliPulKolecko(prumer);
    }

    private void nakresliSnehulaka(double vyskaSnehulaka) {
        double velikostHlava = vyskaSnehulaka / 9 * 2;
        double velikostTelo = vyskaSnehulaka / 9 * 3;
        double velikostNoha = vyskaSnehulaka / 9 * 4;
        double velikostRuka = vyskaSnehulaka / 9 * 1;

        zofka.turnRight(90.0);
        zofka.move(velikostNoha / 2);
        nakresliKolecko(velikostNoha);
        zofka.turnLeft(180.0);
        nakresliKolecko(velikostTelo);
        zofka.turnRight(90.0);
        zofka.move(velikostTelo);
        zofka.turnLeft(90.0);
        nakresliKolecko(velikostHlava);
        zofka.turnLeft(90.0);
        zofka.move(velikostTelo / 2);
        zofka.turnLeft(90.0);
        zofka.move(velikostTelo / 2);
        zofka.turnLeft(90.0);
        nakresliKolecko(velikostRuka);
        zofka.penUp();
        zofka.turnLeft(90.0);
        zofka.move(velikostTelo);
        zofka.turnLeft(90.0);
        nakresliKolecko(velikostRuka);
        zofka.turnLeft(90.0);
        zofka.move(velikostTelo + velikostRuka + 100);
        zofka.turnLeft(90.0);
    }

    private void nakresliMasinku() {
        zofka.turnRight(90.0);
        zofka.move(500.0);
        zofka.turnLeft(90.0);
        nakresliObdelnik(250.0, 130.0);
        zofka.turnLeft(180.0);
        nakresliKolecko(130.0);
        zofka.turnRight(90.0);
        zofka.move(130.0);
        zofka.turnRight(90.0);
        nakresliObdelnik(100.0, 210.0);
        zofka.turnLeft(90.0);
        zofka.move(60.0);
        zofka.turnRight(180.0);
        nakresliKolecko(60.0);
        zofka.turnLeft(180.0);
        zofka.move(90.0);
        zofka.turnRight(180.0);
        nakresliKolecko(60.0);
        zofka.turnRight(90.0);
        zofka.move(30.0);
        zofka.turnRight(90.0);
        zofka.move(60.0);
        nakresliRovnoramennyTrojuhelnik(100.0, 90.0);
    }
}
