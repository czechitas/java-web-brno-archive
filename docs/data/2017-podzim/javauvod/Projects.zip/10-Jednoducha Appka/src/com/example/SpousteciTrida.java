package com.example;

import com.example.util.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        MessageDialog okno;
        String jmeno;

        okno = new MessageDialog();

        jmeno = okno.prompt("Zadejte svoje jméno");
        okno.showMessage("Dobrý den, zdraví " + jmeno);

        okno.close();
    }

}
