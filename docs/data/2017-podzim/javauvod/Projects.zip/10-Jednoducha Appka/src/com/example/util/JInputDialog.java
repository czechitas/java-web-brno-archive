package com.example.util;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import static javax.swing.JOptionPane.*;

public class JInputDialog extends JDialog {

    JLabel labIcon;
    JLabel labMessage;
    JTextField txtUserInput;
    JPanel panOptions;
    JButton btnConfirm;
    JPanel contentPane;

    public static String showPromptDialog(String question) {
        Window activeWindow = FocusManager.getCurrentManager().getActiveWindow();
        JInputDialog dialog = new JInputDialog(activeWindow, ModalityType.APPLICATION_MODAL);
        dialog.setQuestion(question);
        dialog.setVisible(true);
        dialog.dispose();
        return dialog.getText();
    }

    public static void showMessageDialog(String message) throws HeadlessException {
        Window activeWindow = FocusManager.getCurrentManager().getActiveWindow();
        JOptionPane.showMessageDialog(activeWindow, message);
    }

    public static void showMessageDialog(Component parentComponent,
                                         Object message) throws HeadlessException {
        JOptionPane.showMessageDialog(parentComponent, message);
    }

    public static void showMessageDialog(Component parentComponent,
                                         Object message, String title, int messageType)
            throws HeadlessException {
        JOptionPane.showMessageDialog(parentComponent, message, title, messageType);
    }

    public static void showMessageDialog(Component parentComponent,
                                         Object message, String title, int messageType, Icon icon)
            throws HeadlessException {
        JOptionPane.showMessageDialog(parentComponent, message, title, messageType, icon);
    }

    public JInputDialog() {
        initComponents();
    }

    public JInputDialog(Frame owner) {
        super(owner);
        initComponents();
    }

    public JInputDialog(Frame owner, boolean modal) {
        super(owner, modal);
        initComponents();
    }

    public JInputDialog(Frame owner, String title) {
        super(owner, title);
        initComponents();
    }

    public JInputDialog(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        initComponents();
    }

    public JInputDialog(Frame owner, String title, boolean modal, GraphicsConfiguration gc) {
        super(owner, title, modal, gc);
        initComponents();
    }

    public JInputDialog(Dialog owner) {
        super(owner);
        initComponents();
    }

    public JInputDialog(Dialog owner, boolean modal) {
        super(owner, modal);
        initComponents();
    }

    public JInputDialog(Dialog owner, String title) {
        super(owner, title);
        initComponents();
    }

    public JInputDialog(Dialog owner, String title, boolean modal) {
        super(owner, title, modal);
        initComponents();
    }

    public JInputDialog(Dialog owner, String title, boolean modal, GraphicsConfiguration gc) {
        super(owner, title, modal, gc);
        initComponents();
    }

    public JInputDialog(Window owner) {
        super(owner);
        initComponents();
    }

    public JInputDialog(Window owner, ModalityType modalityType) {
        super(owner, modalityType);
        initComponents();
    }

    public JInputDialog(Window owner, String title) {
        super(owner, title);
        initComponents();
    }

    public JInputDialog(Window owner, String title, ModalityType modalityType) {
        super(owner, title, modalityType);
        initComponents();
    }

    public JInputDialog(Window owner, String title, ModalityType modalityType, GraphicsConfiguration gc) {
        super(owner, title, modalityType, gc);
        initComponents();
    }

    private void initComponents() {
        labIcon = new JLabel();
        labMessage = new JLabel();
        txtUserInput = new JTextField();
        panOptions = new JPanel();
        btnConfirm = new JButton();

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Prompt Window");
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridBagLayout());
        ((GridBagLayout) contentPane.getLayout()).columnWidths = new int[] {11, 0, 0, 0, 1, 0};
        ((GridBagLayout) contentPane.getLayout()).rowHeights = new int[] {11, 0, 0, 0, 1, 0};
        ((GridBagLayout) contentPane.getLayout()).columnWeights = new double[] {0.0, 0.0, 0.0, 1.0, 0.0, 1.0E-4};
        ((GridBagLayout) contentPane.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());

        labIcon.setIcon(new ImageIcon(getClass().getResource("question-balloon.png")));
        contentPane.add(labIcon, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 10, 10), 10, 10));

        labMessage.setText("Question?");
        labMessage.setFont(labMessage.getFont().deriveFont(labMessage.getFont().getSize() + 5f));
        contentPane.add(labMessage, new GridBagConstraints(2, 1, 2, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 10, 10), 0, 0));

        txtUserInput.setFont(txtUserInput.getFont().deriveFont(txtUserInput.getFont().getSize() + 5f));
        txtUserInput.setColumns(20);
        contentPane.add(txtUserInput, new GridBagConstraints(2, 2, 2, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 10, 10), 0, 0));

        panOptions.setLayout(new FlowLayout());

        btnConfirm.setText("OK");
        btnConfirm.setFont(btnConfirm.getFont().deriveFont(btnConfirm.getFont().getSize() + 5f));
        btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnConfirmActionPerformed(e);
            }
        });
        panOptions.add(btnConfirm);
        contentPane.add(panOptions, new GridBagConstraints(0, 3, 5, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 10, 0), 0, 0));
        getRootPane().setDefaultButton(btnConfirm);

        pack();
        setLocationRelativeTo(null);
    }

    private void btnConfirmActionPerformed(ActionEvent evt) {
        setVisible(false);
    }

    public String getQuestion() {
        return labMessage.getText();
    }

    public void setQuestion(String text) {
        labMessage.setText(text);
    }

    public String getText() {
        return txtUserInput.getText();
    }

    public void setText(String newValue) {
        txtUserInput.setText(newValue);
    }
}
