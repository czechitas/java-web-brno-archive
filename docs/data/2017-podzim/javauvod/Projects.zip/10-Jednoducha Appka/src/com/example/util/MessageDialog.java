package com.example.util;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import java.util.concurrent.*;
import javax.swing.*;

public class MessageDialog implements AutoCloseable {

    private static JFrame window;

    public MessageDialog() {
        try {
            SwingUtilities.invokeAndWait(this::uiCreateWindow);
        } catch (InterruptedException e) {
            throw new CancellationException();
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    private void uiCreateWindow() {
        if (window == null) {
            window = new JFrame("Application");
            window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            window.setSize(400, 300);
            window.setLocationRelativeTo(null);
            window.setVisible(true);
        }
    }

    public void showMessage(String message) {
        JOptionPane.showMessageDialog(window, message);
    }

    public String prompt(String message) {
        JInputDialog dialog = new JInputDialog(window, true);
        dialog.setQuestion(message);
        dialog.setVisible(true);
        return dialog.getText();
    }

    @Override
    public void close() {
        try {
            SwingUtilities.invokeAndWait(this::uiClose);
        } catch (InterruptedException e) {
            throw new CancellationException();
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    private void uiClose() {
        if (window != null) {
            window.dispose();
            window = null;
        }
    }
}
