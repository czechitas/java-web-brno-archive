package net.sevecek.angrybirds.engine;

public enum TurnDirection {

    LEFT,
    RIGHT;

}
