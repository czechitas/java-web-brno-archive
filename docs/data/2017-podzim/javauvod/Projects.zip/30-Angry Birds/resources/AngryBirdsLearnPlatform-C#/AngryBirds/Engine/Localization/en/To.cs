namespace AngryBirds.Engine.Localization.en
{
    public enum To
    {
        Left = Direction.Left,
        Right = Direction.Right,
    }
}