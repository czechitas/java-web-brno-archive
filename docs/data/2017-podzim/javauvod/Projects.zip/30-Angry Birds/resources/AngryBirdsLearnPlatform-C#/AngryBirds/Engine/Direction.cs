namespace AngryBirds.Engine
{
    public enum Direction
    {
        Left = 0,
        Right = 1,
    }
}