namespace AngryBirds.Engine
{
    public enum TurnType
    {
        Turn0,
        Turn90,
        Turn180,
        Turn270,
    }
}