﻿namespace AngryBirds.Engine.Localization
{
    public enum TypPolicka
    {
        AngryBird = FieldType.AngryBird,
        Prase = FieldType.Pig,
        Prekazka = FieldType.Obstacle,
        Cesta = FieldType.Path
    }
}