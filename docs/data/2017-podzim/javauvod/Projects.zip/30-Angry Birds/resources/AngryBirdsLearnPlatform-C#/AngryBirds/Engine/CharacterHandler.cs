using AngryBirds.Engine.Interfaces;

namespace AngryBirds.Engine
{
    public delegate void CharacterHandler(ICharacter sender);
}