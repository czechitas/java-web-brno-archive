package com.example;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import net.miginfocom.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labJmeno;
    JTextField txtJmeno;
    JButton btnPozdravit;
    JLabel labVysledek;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;

    private void priStiskuPozdravit(ActionEvent e) {
        String jmeno;
        jmeno = txtJmeno.getText();
        labVysledek.setText(jmeno);
    }

    public HlavniOkno() {
        initComponents();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labJmeno = new JLabel();
        txtJmeno = new JTextField();
        btnPozdravit = new JButton();
        labVysledek = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Rozbor jm\u00e9na");
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets 10,hidemode 3",
            // columns
            "[fill]" +
            "[fill]" +
            "[grow,fill]",
            // rows
            "[fill]" +
            "[]" +
            "[grow]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());

        //---- labJmeno ----
        labJmeno.setText("Zadejte svoje jm\u00e9no:");
        labJmeno.setFont(labJmeno.getFont().deriveFont(labJmeno.getFont().getSize() + 3f));
        contentPane.add(labJmeno, "cell 0 0");

        //---- txtJmeno ----
        txtJmeno.setColumns(20);
        txtJmeno.setFont(txtJmeno.getFont().deriveFont(txtJmeno.getFont().getSize() + 3f));
        contentPane.add(txtJmeno, "cell 1 0 2 1");

        //---- btnPozdravit ----
        btnPozdravit.setText("Pozdravit");
        btnPozdravit.setFont(btnPozdravit.getFont().deriveFont(btnPozdravit.getFont().getSize() + 3f));
        btnPozdravit.addActionListener(e -> priStiskuPozdravit(e));
        contentPane.add(btnPozdravit, "cell 1 1");

        //---- labVysledek ----
        labVysledek.setHorizontalAlignment(SwingConstants.CENTER);
        labVysledek.setText("  ");
        labVysledek.setFont(labVysledek.getFont().deriveFont(labVysledek.getFont().getStyle() | Font.BOLD, labVysledek.getFont().getSize() + 8f));
        contentPane.add(labVysledek, "cell 0 2 3 1,gapy 20 20");
        pack();
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
        getRootPane().setDefaultButton(btnPozdravit);
    }
}
