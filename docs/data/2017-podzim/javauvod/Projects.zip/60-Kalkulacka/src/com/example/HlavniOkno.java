package com.example;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import net.miginfocom.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labCisloA;
    JTextField txtCisloA;
    JLabel labCisloB;
    JTextField txtCisloB;
    JButton btnVypocitat;
    JLabel labVysledek;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;

    private void priStiskuPozdravit(ActionEvent e) {
        
        // TODO: Vas kod piste sem!!!

    }

    public HlavniOkno() {
        initComponents();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labCisloA = new JLabel();
        txtCisloA = new JTextField();
        labCisloB = new JLabel();
        txtCisloB = new JTextField();
        btnVypocitat = new JButton();
        labVysledek = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Kalkula\u010dka");
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets 10,hidemode 3",
            // columns
            "[fill]" +
            "[fill]" +
            "[grow,fill]",
            // rows
            "[fill]" +
            "[]" +
            "[]" +
            "[grow]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());

        //---- labCisloA ----
        labCisloA.setText("\u010c\u00edslo A:");
        labCisloA.setFont(labCisloA.getFont().deriveFont(labCisloA.getFont().getSize() + 3f));
        contentPane.add(labCisloA, "cell 0 0");

        //---- txtCisloA ----
        txtCisloA.setColumns(20);
        txtCisloA.setFont(txtCisloA.getFont().deriveFont(txtCisloA.getFont().getSize() + 3f));
        contentPane.add(txtCisloA, "cell 1 0 2 1");

        //---- labCisloB ----
        labCisloB.setText("\u010c\u00edslo B:");
        labCisloB.setHorizontalAlignment(SwingConstants.TRAILING);
        labCisloB.setFont(labCisloB.getFont().deriveFont(labCisloB.getFont().getSize() + 3f));
        contentPane.add(labCisloB, "cell 0 1");

        //---- txtCisloB ----
        txtCisloB.setFont(txtCisloB.getFont().deriveFont(txtCisloB.getFont().getSize() + 3f));
        contentPane.add(txtCisloB, "cell 1 1 2 1");

        //---- btnVypocitat ----
        btnVypocitat.setText("Se\u010d\u00edst");
        btnVypocitat.setFont(btnVypocitat.getFont().deriveFont(btnVypocitat.getFont().getSize() + 3f));
        btnVypocitat.addActionListener(e -> priStiskuPozdravit(e));
        contentPane.add(btnVypocitat, "cell 1 2");

        //---- labVysledek ----
        labVysledek.setHorizontalAlignment(SwingConstants.CENTER);
        labVysledek.setText("  ");
        labVysledek.setFont(labVysledek.getFont().deriveFont(labVysledek.getFont().getStyle() | Font.BOLD, labVysledek.getFont().getSize() + 8f));
        contentPane.add(labVysledek, "cell 0 3 3 1,gapy 20 20");
        pack();
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
        getRootPane().setDefaultButton(btnVypocitat);
    }
}
