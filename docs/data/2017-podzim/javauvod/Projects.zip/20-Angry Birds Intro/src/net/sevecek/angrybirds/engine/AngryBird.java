package net.sevecek.angrybirds.engine;

import javax.swing.*;

public class AngryBird {

    private static int totalBirdCount = 0;

    private GameBoard gameBoard;
    private JLabel sprite;
    private Direction direction;
    private ImageIcon uiRightSprite;
    private ImageIcon uiLeftSprite;
    private ImageIcon uiUpSprite;
    private ImageIcon uiDownSprite;

    public AngryBird() {
        gameBoard = GameBoard.getInstance();

        totalBirdCount++;
        if (totalBirdCount % 2 == 1) {
            uiRightSprite = new ImageIcon(this.getClass().getClassLoader().getResource("net/sevecek/angrybirds/images/AngryBird-right.png"));
            uiDownSprite = new ImageIcon(this.getClass().getClassLoader().getResource("net/sevecek/angrybirds/images/AngryBird-down.png"));
            uiLeftSprite = new ImageIcon(this.getClass().getClassLoader().getResource("net/sevecek/angrybirds/images/AngryBird-left.png"));
            uiUpSprite = new ImageIcon(this.getClass().getClassLoader().getResource("net/sevecek/angrybirds/images/AngryBird-up.png"));
        } else {
            uiRightSprite = new ImageIcon(this.getClass().getClassLoader().getResource("net/sevecek/angrybirds/images/Matylda-right.png"));
            uiDownSprite = new ImageIcon(this.getClass().getClassLoader().getResource("net/sevecek/angrybirds/images/Matylda-down.png"));
            uiLeftSprite = new ImageIcon(this.getClass().getClassLoader().getResource("net/sevecek/angrybirds/images/Matylda-left.png"));
            uiUpSprite = new ImageIcon(this.getClass().getClassLoader().getResource("net/sevecek/angrybirds/images/Matylda-up.png"));
        }

        direction = Direction.RIGHT;
        sprite = new JLabel();
        uiUpdateSprite();

        gameBoard.invokeAndWait(() -> {
            gameBoard.add(sprite);
            sprite.setSize(sprite.getPreferredSize());
            sprite.setLocation(100, 100);
        });
    }

    public void move() {
        gameBoard.invokeAndWait(this::uiMove);
    }

    public void turnLeft() {
        gameBoard.invokeAndWait(this::uiTurnLeft);
    }

    public void turnRight() {
        gameBoard.invokeAndWait(this::uiTurnRight);
    }

    private void uiTurnRight() {
        if (direction == Direction.LEFT) {
            direction = Direction.UP;
        } else if (direction == Direction.UP) {
            direction = Direction.RIGHT;
        } else if (direction == Direction.RIGHT) {
            direction = Direction.DOWN;
        } else if (direction == Direction.DOWN) {
            direction = Direction.LEFT;
        }
        uiUpdateSprite();
    }

    private void uiTurnLeft() {
        if (direction == Direction.LEFT) {
            direction = Direction.DOWN;
        } else if (direction == Direction.UP) {
            direction = Direction.LEFT;
        } else if (direction == Direction.RIGHT) {
            direction = Direction.UP;
        } else if (direction == Direction.DOWN) {
            direction = Direction.RIGHT;
        }
        uiUpdateSprite();
    }

    private void uiUpdateSprite() {
        if (direction == Direction.LEFT) {
            sprite.setIcon(uiLeftSprite);
        } else if (direction == Direction.UP) {
            sprite.setIcon(uiUpSprite);
        } else if (direction == Direction.RIGHT) {
            sprite.setIcon(uiRightSprite);
        } else if (direction == Direction.DOWN) {
            sprite.setIcon(uiDownSprite);
        }
    }

    private void uiMove() {
        int x = sprite.getLocation().x;
        int y = sprite.getLocation().y;
        if (direction == Direction.RIGHT) {
            x = x + GameBoard.STEP_PIXELS;
        } else if (direction == Direction.UP) {
            y = y - GameBoard.STEP_PIXELS;
        } else if (direction == Direction.DOWN) {
            y = y + GameBoard.STEP_PIXELS;
        } else if (direction == Direction.LEFT) {
            x = x - GameBoard.STEP_PIXELS;
        }
        sprite.setLocation(x, y);
    }
}
