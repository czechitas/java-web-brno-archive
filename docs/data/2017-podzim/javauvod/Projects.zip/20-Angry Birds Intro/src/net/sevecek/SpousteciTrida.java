package net.sevecek;

import net.sevecek.angrybirds.engine.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        AngryBird cervenyPtak;
        AngryBird bilyPtak;

        cervenyPtak = new AngryBird();

        cervenyPtak.move();
        cervenyPtak.move();
        cervenyPtak.turnLeft();
        cervenyPtak.move();
        cervenyPtak.move();

        bilyPtak = new AngryBird();
        bilyPtak.turnLeft();
        bilyPtak.turnLeft();
        bilyPtak.move();
        bilyPtak.move();

        cervenyPtak.move();
        cervenyPtak.turnRight();
        cervenyPtak.move();
        cervenyPtak.move();

        bilyPtak.turnRight();
        bilyPtak.move();
        bilyPtak.move();
    }

}
