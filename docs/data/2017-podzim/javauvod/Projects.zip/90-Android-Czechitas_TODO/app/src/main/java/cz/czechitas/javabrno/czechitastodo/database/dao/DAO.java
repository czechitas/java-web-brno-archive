package cz.czechitas.javabrno.czechitastodo.database.dao;

import java.util.List;


public interface DAO<T> {

    public Long create(T t);

    public T read(Long id);

    public List<T> readAll();

    public Long update(T t);

    public void delete(Long id);
}
