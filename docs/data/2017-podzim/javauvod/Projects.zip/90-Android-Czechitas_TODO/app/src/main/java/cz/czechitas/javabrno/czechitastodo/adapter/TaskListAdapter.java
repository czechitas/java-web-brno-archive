package cz.czechitas.javabrno.czechitastodo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.List;

import cz.czechitas.javabrno.czechitastodo.R;
import cz.czechitas.javabrno.czechitastodo.database.dao.TaskDAO;
import cz.czechitas.javabrno.czechitastodo.entity.TaskEntity;
import cz.czechitas.javabrno.czechitastodo.utility.DateConvertor;


public class TaskListAdapter extends BaseAdapter {

    private Context mContext;
    private List<TaskEntity> mTaskList;


    public TaskListAdapter(Context context, List<TaskEntity> taskList) {
        mContext = context;
        mTaskList = taskList;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // inflate view
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.activity_task_list_item, parent, false);

            // view holder
            ViewHolder holder = new ViewHolder();
            holder.titleTextView = (TextView) view.findViewById(R.id.title);
            holder.dateTextView = (TextView) view.findViewById(R.id.date);
            holder.statusCheckBox = (CheckBox) view.findViewById(R.id.status);
            view.setTag(holder);
        }

        // entity
        final TaskEntity task = mTaskList.get(position);

        if (task != null) {
            // view holder
            ViewHolder holder = (ViewHolder) view.getTag();

            // content
            holder.statusCheckBox.setChecked(task.isStatus());
            holder.titleTextView.setText(task.getTitle());
            holder.dateTextView.setText(DateConvertor.dateToString(task.getDate(), "d.M.yyyy"));

            // checkbox
            holder.statusCheckBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // is checkbox checked
                    boolean isChecked = ((CheckBox) view).isChecked();

                    // status has changed
                    if (task.isStatus() != isChecked) {
                        task.setStatus(isChecked);
                        updateTask(task);
                    }
                }
            });
        }

        return view;
    }


    @Override
    public int getCount() {
        if (mTaskList != null) return mTaskList.size();
        else return 0;
    }


    @Override
    public Object getItem(int position) {
        if (mTaskList != null) return mTaskList.get(position);
        else return null;
    }


    @Override
    public long getItemId(int position) {
        return position;
    }


    public void refill(Context context, List<TaskEntity> taskList) {
        mContext = context;
        mTaskList = taskList;
        notifyDataSetChanged();
    }


    private void updateTask(TaskEntity task) {
        TaskDAO dao = new TaskDAO();
        dao.update(task);
    }


    static class ViewHolder {
        CheckBox statusCheckBox;
        TextView titleTextView;
        TextView dateTextView;
    }
}
