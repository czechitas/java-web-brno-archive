package cz.czechitas.javabrno.czechitastodo.database.dao;

import com.orm.SugarRecord;

import java.util.List;

import cz.czechitas.javabrno.czechitastodo.entity.TaskEntity;


public class TaskDAO implements DAO<TaskEntity> {

    @Override
    public Long create(TaskEntity task) {
        task.save();
        return task.getId();
    }

    @Override
    public TaskEntity read(Long id) {
        return SugarRecord.findById(TaskEntity.class, id);
    }


    @Override
    public List<TaskEntity> readAll() {
        return SugarRecord.listAll(TaskEntity.class);
    }


    @Override
    public Long update(TaskEntity task) {
        task.save();
        return task.getId();
    }


    @Override
    public void delete(Long id) {
        TaskEntity.delete(read(id));
    }

}
