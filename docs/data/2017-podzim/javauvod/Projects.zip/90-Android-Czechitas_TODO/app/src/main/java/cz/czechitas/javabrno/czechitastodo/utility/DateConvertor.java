package cz.czechitas.javabrno.czechitastodo.utility;

import java.text.SimpleDateFormat;
import java.util.Date;


public class DateConvertor {

    public static String dateToString(Date date, String format) {
        String str = null;
        if (date != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat(format);
            str = dateFormat.format(date);
        }
        return str;
    }
}
