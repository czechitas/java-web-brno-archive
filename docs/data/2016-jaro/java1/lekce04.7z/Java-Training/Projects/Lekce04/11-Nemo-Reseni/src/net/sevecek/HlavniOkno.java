package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.border.*;
import net.sevecek.util.swing.*;

public class HlavniOkno extends JFrame {

    Container contentPane;
    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - Kurz Czechitas
    JLabel labRybicka;
    // JFormDesigner - End of variables declaration  //GEN-END:variables


    private void priStiskuKlavesy(KeyEvent e) {
        Point poloha = labRybicka.getLocation();
        Integer x = poloha.x;
        Integer y = poloha.y;
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            x = x - 10;
        }
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            x = x + 10;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            y = y - 10;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            y = y + 10;
        }
        poloha.x = x;
        poloha.y = y;
        labRybicka.setLocation(poloha);
    }

    private void priOtevreniOkna(WindowEvent e) {
        contentPane = getContentPane();
        contentPane.setBackground(new Color(51, 153, 255));
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - Kurz Czechitas
        labRybicka = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Czechitas");
        setBackground(new Color(51, 153, 255));
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                priOtevreniOkna(e);
            }
        });
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                priStiskuKlavesy(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- labRybicka ----
        labRybicka.setIcon(new ImageIcon(getClass().getResource("/net/sevecek/Nemo-Left.png")));
        contentPane.add(labRybicka);
        labRybicka.setBounds(new Rectangle(new Point(195, 150), labRybicka.getPreferredSize()));

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(650, 475);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
