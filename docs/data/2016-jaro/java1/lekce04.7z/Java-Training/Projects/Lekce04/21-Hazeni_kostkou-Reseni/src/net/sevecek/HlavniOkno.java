package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - Kurz Czechitas
    JButton btnHodKostkou;
    JLabel labHozeno;
    JTextField txtHozeno;
    Random generatorCisel;
    // JFormDesigner - End of variables declaration  //GEN-END:variables


    private void priStiskuBtnHodkostkou(ActionEvent e) {
        Integer cislo = generatorCisel.nextInt(6) + 1;
        String text = cislo.toString();
        txtHozeno.setText(text);
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - Kurz Czechitas
        btnHodKostkou = new JButton();
        labHozeno = new JLabel();
        txtHozeno = new JTextField();
        generatorCisel = new Random();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Czechitas");
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- btnHodKostkou ----
        btnHodKostkou.setIcon(new ImageIcon(getClass().getResource("/net/sevecek/hraci-kostka.png")));
        btnHodKostkou.addActionListener(e -> priStiskuBtnHodkostkou(e));
        contentPane.add(btnHodKostkou);
        btnHodKostkou.setBounds(new Rectangle(new Point(75, 15), btnHodKostkou.getPreferredSize()));

        //---- labHozeno ----
        labHozeno.setText("Hozeno na kostce:");
        labHozeno.setFont(labHozeno.getFont().deriveFont(labHozeno.getFont().getSize() + 4f));
        contentPane.add(labHozeno);
        labHozeno.setBounds(new Rectangle(new Point(20, 125), labHozeno.getPreferredSize()));

        //---- txtHozeno ----
        txtHozeno.setFont(txtHozeno.getFont().deriveFont(txtHozeno.getFont().getSize() + 4f));
        contentPane.add(txtHozeno);
        txtHozeno.setBounds(155, 120, 75, txtHozeno.getPreferredSize().height);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(265, 200);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
