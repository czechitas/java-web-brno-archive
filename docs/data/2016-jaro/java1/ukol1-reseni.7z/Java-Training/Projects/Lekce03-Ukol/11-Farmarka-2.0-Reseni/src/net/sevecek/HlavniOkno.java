package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - Kurz Czechitas
    JLabel labKralici;
    JLabel labHusy;
    JLabel labEvidence;
    JLabel labKrmivo;
    JLabel labKraliciSamci;
    JLabel labKraliciSamice;
    JLabel labHusySamci;
    JLabel labHusySamice;
    JLabel labChov;
    JLabel labKraliciChov;
    JLabel labHusyChov;
    JLabel labMrkev;
    JLabel labPsenice;
    JButton btnVypocti;
    JTextField txtKraliciSamci;
    JTextField txtKraliciSamice;
    JTextField txtHusySamci;
    JTextField txtHusySamice;
    JLabel labMusiteVypestovat;
    // JFormDesigner - End of variables declaration  //GEN-END:variables

    private void poKliknutiVypocti(ActionEvent e) {
        // Nejprve vytvoříme proměnné, do kterých se uloží hodnoty, které zadá uživatel.
        String sKraliciPocetSamic = txtKraliciSamice.getText();
        String sKraliciPocetSamcu = txtKraliciSamci.getText();
        String sHusyPocetSamic = txtHusySamice.getText();
        String sHusyPocetSamcu = txtHusySamci.getText();

        // Poté je převedeme na čísla, abychom s nimi mohli počítat.
        Integer iKraliciPocetSamic = new Integer(sKraliciPocetSamic);
        Integer iKraliciPocetSamcu = new Integer(sKraliciPocetSamcu);
        Integer iHusyPocetSamic = new Integer(sHusyPocetSamic);
        Integer iHusyPocetSamcu = new Integer(sHusyPocetSamcu);

        // A provedeme výpočty, ke kterým si vytvoříme proměnné. Nesmíme ale zapomenout ohlídat
        // pokud v chovu nemáme zastoupeny obě pohlaví. Výpočty zobrazíme v příslušných labelech,
        // po převodu zpět na Stringy.
        Integer iKraliciPocetMladat = iKraliciPocetSamic * 4 * 10;
        Integer iHusyPocetMladat = iHusyPocetSamic * 15;
        Integer iKraliciVelikostChovu;
        Integer iHusyVelikostChovu;

        if (iKraliciPocetSamic > 0 && iKraliciPocetSamcu > 0) {
            iKraliciVelikostChovu = iKraliciPocetMladat + iKraliciPocetSamcu + iKraliciPocetSamic;
        } else {
            iKraliciVelikostChovu = iKraliciPocetSamcu + iKraliciPocetSamic;
        }

        if (iHusyPocetSamic > 0 && iHusyPocetSamcu > 0) {
            iHusyVelikostChovu = iHusyPocetMladat + iHusyPocetSamcu + iHusyPocetSamic;
        } else {
            iHusyVelikostChovu = iHusyPocetSamcu + iHusyPocetSamic;
        }

        Double dKgMrkve = iKraliciVelikostChovu * 183 * 0.5D;
        Double dRadkyMrkve = dKgMrkve / 5;
        Double dKgPsenice = iHusyVelikostChovu * 183 *0.25D;
        Double dRadkyPsenice = dKgPsenice / 2;

        String sKraliciChov = iKraliciVelikostChovu.toString();
        String sHusyChov = iHusyVelikostChovu.toString();
        String sKgMrkve = dKgMrkve.toString();
        String sKgPsenice = dKgPsenice.toString();
        String sRadkyMrkve = dRadkyMrkve.toString();
        String sRadkyPsenice = dRadkyPsenice.toString();

        labKraliciChov.setText(sKraliciChov + " ks králíků");
        labHusyChov.setText(sHusyChov + " ks hus");
        labMrkev.setText(sKgMrkve + " kg mrkve, tedy " + sRadkyMrkve + " řádků.");
        labPsenice.setText(sKgPsenice + " kg pšenice, tedy " + sRadkyPsenice + " řádků.");
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - Kurz Czechitas
        labKralici = new JLabel();
        labHusy = new JLabel();
        labEvidence = new JLabel();
        labKrmivo = new JLabel();
        labKraliciSamci = new JLabel();
        labKraliciSamice = new JLabel();
        labHusySamci = new JLabel();
        labHusySamice = new JLabel();
        labChov = new JLabel();
        labKraliciChov = new JLabel();
        labHusyChov = new JLabel();
        labMrkev = new JLabel();
        labPsenice = new JLabel();
        btnVypocti = new JButton();
        txtKraliciSamci = new JTextField();
        txtKraliciSamice = new JTextField();
        txtHusySamci = new JTextField();
        txtHusySamice = new JTextField();
        labMusiteVypestovat = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Farm\u00e1\u0159 2.0");
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- labKralici ----
        labKralici.setText("Kr\u00e1l\u00edci");
        labKralici.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        contentPane.add(labKralici);
        labKralici.setBounds(20, 50, 100, 20);

        //---- labHusy ----
        labHusy.setText("Husy");
        labHusy.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        contentPane.add(labHusy);
        labHusy.setBounds(new Rectangle(new Point(300, 50), labHusy.getPreferredSize()));

        //---- labEvidence ----
        labEvidence.setText("Evidence kr\u00e1l\u00edk\u016f a hus");
        labEvidence.setFont(new Font("Monotype Corsiva", Font.BOLD, 22));
        labEvidence.setEnabled(false);
        contentPane.add(labEvidence);
        labEvidence.setBounds(20, 20, 370, 20);

        //---- labKrmivo ----
        labKrmivo.setText("Pot\u0159eba krmiva ");
        labKrmivo.setFont(new Font("Monotype Corsiva", Font.ITALIC, 20));
        contentPane.add(labKrmivo);
        labKrmivo.setBounds(20, 285, labKrmivo.getPreferredSize().width, 20);

        //---- labKraliciSamci ----
        labKraliciSamci.setText("Po\u010det samc\u016f");
        contentPane.add(labKraliciSamci);
        labKraliciSamci.setBounds(new Rectangle(new Point(20, 90), labKraliciSamci.getPreferredSize()));

        //---- labKraliciSamice ----
        labKraliciSamice.setText("Po\u010det samic");
        contentPane.add(labKraliciSamice);
        labKraliciSamice.setBounds(new Rectangle(new Point(20, 120), labKraliciSamice.getPreferredSize()));

        //---- labHusySamci ----
        labHusySamci.setText("Po\u010det samc\u016f");
        contentPane.add(labHusySamci);
        labHusySamci.setBounds(300, 90, 77, 20);

        //---- labHusySamice ----
        labHusySamice.setText("Po\u010det samic");
        contentPane.add(labHusySamice);
        labHusySamice.setBounds(300, 120, 72, 20);

        //---- labChov ----
        labChov.setText("Velikost chovu p\u0159ed zimou:");
        labChov.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        contentPane.add(labChov);
        labChov.setBounds(20, 205, labChov.getPreferredSize().width, 21);
        contentPane.add(labKraliciChov);
        labKraliciChov.setBounds(20, 240, 140, 20);
        contentPane.add(labHusyChov);
        labHusyChov.setBounds(300, 240, 140, 20);

        //---- labMrkev ----
        labMrkev.setForeground(Color.red);
        contentPane.add(labMrkev);
        labMrkev.setBounds(20, 340, 530, 20);

        //---- labPsenice ----
        labPsenice.setForeground(Color.blue);
        contentPane.add(labPsenice);
        labPsenice.setBounds(20, 370, 530, 20);

        //---- btnVypocti ----
        btnVypocti.setText("Vypo\u010dti");
        btnVypocti.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        btnVypocti.addActionListener(e -> poKliknutiVypocti(e));
        contentPane.add(btnVypocti);
        btnVypocti.setBounds(20, 150, 545, btnVypocti.getPreferredSize().height);
        contentPane.add(txtKraliciSamci);
        txtKraliciSamci.setBounds(120, 90, 100, 20);
        contentPane.add(txtKraliciSamice);
        txtKraliciSamice.setBounds(120, 120, 100, 20);
        contentPane.add(txtHusySamci);
        txtHusySamci.setBounds(405, 90, 100, 20);
        contentPane.add(txtHusySamice);
        txtHusySamice.setBounds(405, 120, 100, 20);

        //---- labMusiteVypestovat ----
        labMusiteVypestovat.setText("P\u0159ed zimou mus\u00edte vyp\u011bstovat:");
        contentPane.add(labMusiteVypestovat);
        labMusiteVypestovat.setBounds(new Rectangle(new Point(20, 315), labMusiteVypestovat.getPreferredSize()));

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(605, 450);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
