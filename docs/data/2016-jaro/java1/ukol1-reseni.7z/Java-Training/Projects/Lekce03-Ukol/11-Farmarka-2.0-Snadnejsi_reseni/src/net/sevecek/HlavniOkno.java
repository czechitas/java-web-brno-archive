package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - Kurz Czechitas
    JLabel labKralici;
    JLabel labHusy;
    JLabel labEvidence;
    JLabel labKrmivo;
    JLabel labKraliciPocet;
    JLabel labHusyPocet;
    JLabel labMrkev;
    JLabel labPsenice;
    JLabel labMusiteVypestovat;
    JButton btnVypocti;
    JTextField txtKraliciPocet;
    JTextField txtHusyPocet;
    // JFormDesigner - End of variables declaration  //GEN-END:variables

    private void poKliknutiVypocti(ActionEvent e) {
        // Nejprve vytvoříme proměnné, do kterých se uloží hodnoty, které zadá uživatel.
        String sKraliciPocet = txtKraliciPocet.getText();
        String sHusyPocet = txtHusyPocet.getText();

        // Poté je převedeme na čísla, abychom s nimi mohli počítat.
        Integer iKraliciPocet = new Integer(sKraliciPocet);
        Integer iHusyPocet = new Integer(sHusyPocet);

        // A provedeme výpočty, ke kterým si vytvoříme proměnné. Výpočty zobrazíme v příslušných labelech,
        // po převodu zpět na Stringy.
        Double dKgMrkve = iKraliciPocet * 183 * 0.5D;
        Double dRadkyMrkve = dKgMrkve / 5;
        Double dKgPsenice = iHusyPocet * 183 *0.25D;
        Double dRadkyPsenice = dKgPsenice / 2;

        String sKgMrkve = dKgMrkve.toString();
        String sKgPsenice = dKgPsenice.toString();
        String sRadkyMrkve = dRadkyMrkve.toString();
        String sRadkyPsenice = dRadkyPsenice.toString();

        labMrkev.setText(sKgMrkve + " kg mrkve, tedy " + sRadkyMrkve + " řádků.");
        labPsenice.setText(sKgPsenice + " kg pšenice, tedy " + sRadkyPsenice + " řádků.");
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - Kurz Czechitas
        labKralici = new JLabel();
        labHusy = new JLabel();
        labEvidence = new JLabel();
        labKrmivo = new JLabel();
        labKraliciPocet = new JLabel();
        labHusyPocet = new JLabel();
        labMrkev = new JLabel();
        labPsenice = new JLabel();
        labMusiteVypestovat = new JLabel();
        btnVypocti = new JButton();
        txtKraliciPocet = new JTextField();
        txtHusyPocet = new JTextField();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Farm\u00e1\u0159 2.0");
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- labKralici ----
        labKralici.setText("Kr\u00e1l\u00edci");
        labKralici.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        contentPane.add(labKralici);
        labKralici.setBounds(20, 50, 100, 20);

        //---- labHusy ----
        labHusy.setText("Husy");
        labHusy.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        contentPane.add(labHusy);
        labHusy.setBounds(new Rectangle(new Point(300, 50), labHusy.getPreferredSize()));

        //---- labEvidence ----
        labEvidence.setText("Evidence kr\u00e1l\u00edk\u016f a hus");
        labEvidence.setFont(new Font("Monotype Corsiva", Font.BOLD, 22));
        labEvidence.setEnabled(false);
        contentPane.add(labEvidence);
        labEvidence.setBounds(20, 20, 370, 20);

        //---- labKrmivo ----
        labKrmivo.setText("Pot\u0159eba krmiva ");
        labKrmivo.setFont(new Font("Monotype Corsiva", Font.ITALIC, 20));
        contentPane.add(labKrmivo);
        labKrmivo.setBounds(20, 215, labKrmivo.getPreferredSize().width, 20);

        //---- labKraliciPocet ----
        labKraliciPocet.setText("Po\u010det");
        contentPane.add(labKraliciPocet);
        labKraliciPocet.setBounds(new Rectangle(new Point(20, 90), labKraliciPocet.getPreferredSize()));

        //---- labHusyPocet ----
        labHusyPocet.setText("Po\u010det");
        contentPane.add(labHusyPocet);
        labHusyPocet.setBounds(300, 90, 77, 20);

        //---- labMrkev ----
        labMrkev.setForeground(Color.red);
        contentPane.add(labMrkev);
        labMrkev.setBounds(20, 270, 530, 20);

        //---- labPsenice ----
        labPsenice.setForeground(Color.blue);
        contentPane.add(labPsenice);
        labPsenice.setBounds(20, 300, 530, 20);

        //---- labMusiteVypestovat ----
        labMusiteVypestovat.setText("P\u0159ed zimou mus\u00edte vyp\u011bstovat:");
        contentPane.add(labMusiteVypestovat);
        labMusiteVypestovat.setBounds(new Rectangle(new Point(20, 245), labMusiteVypestovat.getPreferredSize()));

        //---- btnVypocti ----
        btnVypocti.setText("Vypo\u010dti");
        btnVypocti.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        btnVypocti.addActionListener(e -> poKliknutiVypocti(e));
        contentPane.add(btnVypocti);
        btnVypocti.setBounds(20, 150, 545, btnVypocti.getPreferredSize().height);
        contentPane.add(txtKraliciPocet);
        txtKraliciPocet.setBounds(120, 90, 100, 20);
        contentPane.add(txtHusyPocet);
        txtHusyPocet.setBounds(405, 90, 100, 20);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(605, 380);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}