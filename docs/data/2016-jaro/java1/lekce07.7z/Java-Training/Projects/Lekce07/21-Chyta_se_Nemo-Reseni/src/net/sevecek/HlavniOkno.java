package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import net.sevecek.util.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JKeyboard klavesnice;
    JLabel labRybicka;
    JLabel labZralok;
    JTimer casovac;
    Random generatorNahodnehoCisla;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;
    ImageIcon rybickaDoprava;
    ImageIcon rybickaDoleva;
    Integer pohybZralokaY;

    private void priTiknuti(ActionEvent e) {
        posunNema();
        posunZraloka();
        otestujSezraniRyby();
    }

    private void posunNema() {
        if (klavesnice.isKeyDown(KeyEvent.VK_LEFT)) {
            Point poloha = labRybicka.getLocation();
            poloha.x = poloha.x - 10;
            labRybicka.setLocation(poloha);
            labRybicka.setIcon(rybickaDoleva);
        }
        if (klavesnice.isKeyDown(KeyEvent.VK_RIGHT)) {
            Point poloha = labRybicka.getLocation();
            poloha.x = poloha.x + 10;
            labRybicka.setLocation(poloha);
            labRybicka.setIcon(rybickaDoprava);
        }
        if (klavesnice.isKeyDown(KeyEvent.VK_UP)) {
            Point poloha = labRybicka.getLocation();
            poloha.y = poloha.y - 10;
            labRybicka.setLocation(poloha);
        }
        if (klavesnice.isKeyDown(KeyEvent.VK_DOWN)) {
            Point poloha = labRybicka.getLocation();
            poloha.y = poloha.y + 10;
            labRybicka.setLocation(poloha);
        }
    }

    private void posunZraloka() {
        Point polohaZraloka = labZralok.getLocation();
        Integer zralokX = polohaZraloka.x;
        Integer zralokY = polohaZraloka.y;

        if (zralokX > contentPane.getWidth()) {
            zralokX = -200;
            zralokY = generatorNahodnehoCisla.nextInt(contentPane.getHeight());
            pohybZralokaY = generatorNahodnehoCisla.nextInt(10) - 5;
            if (!labRybicka.isVisible()) {
                labRybicka.setLocation(400, 300);
                labRybicka.setVisible(true);
            }
        }

        zralokX = zralokX + 6;
        zralokY = zralokY + pohybZralokaY;
        labZralok.setLocation(zralokX, zralokY);
    }

    private void otestujSezraniRyby() {
        Point polohaZraloka = labZralok.getLocation();
        Integer zralokX = polohaZraloka.x;
        Integer zralokY = polohaZraloka.y;

        Point polohaNema = labRybicka.getLocation();
        Integer nemoX = polohaNema.x;
        Integer nemoY = polohaNema.y;

        if (((nemoX + labRybicka.getWidth() >= zralokX + 50) && (nemoX <= zralokX + labZralok.getWidth())) &&
                ((nemoY + labRybicka.getHeight() >= zralokY + 50) && (nemoY <= zralokY + labZralok.getHeight() - 20)) &&
                labRybicka.isVisible()) {
            labRybicka.setVisible(false);
        }
    }

    private void priOtevreniOkna(WindowEvent e) {
        casovac.start();
        contentPane = getContentPane();
        contentPane.setBackground(new Color(51, 153, 255));
        rybickaDoprava = new ImageIcon(getClass().getResource("/net/sevecek/Nemo-vpravo.png"));
        rybickaDoleva = new ImageIcon(getClass().getResource("/net/sevecek/Nemo-vlevo.png"));
        pohybZralokaY = 0;
    }

    private void priZavreniOkna(WindowEvent e) {
        casovac.stop();
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        klavesnice = new JKeyboard();
        labRybicka = new JLabel();
        labZralok = new JLabel();
        casovac = new JTimer();
        generatorNahodnehoCisla = new Random();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Czechitas");
        setBackground(new Color(51, 153, 255));
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                priZavreniOkna(e);
            }
            @Override
            public void windowOpened(WindowEvent e) {
                priOtevreniOkna(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(null);
        contentPane.add(klavesnice);
        klavesnice.setBounds(new Rectangle(new Point(5, 5), klavesnice.getPreferredSize()));

        //---- labRybicka ----
        labRybicka.setIcon(new ImageIcon(getClass().getResource("/net/sevecek/Nemo-vpravo.png")));
        contentPane.add(labRybicka);
        labRybicka.setBounds(new Rectangle(new Point(315, 210), labRybicka.getPreferredSize()));

        //---- labZralok ----
        labZralok.setIcon(new ImageIcon(getClass().getResource("/net/sevecek/zralok.png")));
        contentPane.add(labZralok);
        labZralok.setBounds(new Rectangle(new Point(10, 15), labZralok.getPreferredSize()));

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(650, 475);
        setLocationRelativeTo(null);

        //---- casovac ----
        casovac.setDelay(50);
        casovac.addActionListener(e -> priTiknuti(e));
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
