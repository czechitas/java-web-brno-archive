package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.border.*;
import net.sevecek.util.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JKeyboard klavesnice;
    JLabel labRybicka;
    JTimer casovac;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;
    ImageIcon rybickaDoprava;
    ImageIcon rybickaDoleva;

    private void priTiknuti(ActionEvent e) {
        if (klavesnice.isKeyDown(KeyEvent.VK_LEFT)) {
            Point poloha = labRybicka.getLocation();
            poloha.x = poloha.x - 10;
            labRybicka.setLocation(poloha);
            labRybicka.setIcon(rybickaDoleva);
        }
        if (klavesnice.isKeyDown(KeyEvent.VK_RIGHT)) {
            Point poloha = labRybicka.getLocation();
            poloha.x = poloha.x + 10;
            labRybicka.setLocation(poloha);
            labRybicka.setIcon(rybickaDoprava);
        }
        if (klavesnice.isKeyDown(KeyEvent.VK_UP)) {
            Point poloha = labRybicka.getLocation();
            poloha.y = poloha.y - 10;
            labRybicka.setLocation(poloha);
        }
        if (klavesnice.isKeyDown(KeyEvent.VK_DOWN)) {
            Point poloha = labRybicka.getLocation();
            poloha.y = poloha.y + 10;
            labRybicka.setLocation(poloha);
        }
    }

    private void priOtevreniOkna(WindowEvent e) {
        casovac.start();
        contentPane.setBackground(new Color(51, 153, 255));
        rybickaDoprava = new ImageIcon(getClass().getResource("/net/sevecek/Nemo-vpravo.png"));
        rybickaDoleva = new ImageIcon(getClass().getResource("/net/sevecek/Nemo-vlevo.png"));
    }

    private void priZavreniOkna(WindowEvent e) {
        casovac.stop();
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        klavesnice = new JKeyboard();
        labRybicka = new JLabel();
        casovac = new JTimer();

        //======== this ========
        contentPane = getContentPane();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Czechitas");
        setBackground(new Color(51, 153, 255));
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                priZavreniOkna(e);
            }
            @Override
            public void windowOpened(WindowEvent e) {
                priOtevreniOkna(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(null);
        contentPane.add(klavesnice);
        klavesnice.setBounds(new Rectangle(new Point(5, 5), klavesnice.getPreferredSize()));

        //---- labRybicka ----
        labRybicka.setIcon(new ImageIcon(getClass().getResource("/net/sevecek/Nemo-vpravo.png")));
        contentPane.add(labRybicka);
        labRybicka.setBounds(new Rectangle(new Point(195, 150), labRybicka.getPreferredSize()));

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(650, 475);
        setLocationRelativeTo(null);

        //---- casovac ----
        casovac.setDelay(50);
        casovac.addActionListener(e -> priTiknuti(e));
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
