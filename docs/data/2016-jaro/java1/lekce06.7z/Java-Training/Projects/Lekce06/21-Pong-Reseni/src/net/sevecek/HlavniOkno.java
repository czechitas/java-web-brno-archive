package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import net.sevecek.util.swing.*;

public class HlavniOkno extends JFrame {


    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labMic;
    JTimer casovac;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;
    Integer deltaX;
    Integer deltaY;


    private void priTiknutiCasovace(ActionEvent e) {
        Point poziceMice = labMic.getLocation();
        Integer x = poziceMice.x;
        Integer y = poziceMice.y;
        x = x + deltaX;
        y = y + deltaY;

        if (x < 0) {
            deltaX = 5;
        }
        if (x+labMic.getWidth() > contentPane.getWidth()) {
            deltaX = -5;
        }
        if (y < 0) {
            deltaY = 5;
        }
        if (y+labMic.getHeight() > contentPane.getHeight()) {
            deltaY = -5;
        }

        poziceMice.x = x;
        poziceMice.y = y;
        labMic.setLocation(poziceMice);
    }

    private void priStiskuMysiNaMic(MouseEvent e) {
        deltaX = 5;
        deltaY = 5;
        casovac.start();
    }

    private void priZaviraniOkna(WindowEvent e) {
        casovac.stop();
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labMic = new JLabel();
        casovac = new JTimer();

        //======== this ========
        this.contentPane = getContentPane();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Czechitas");
        setBackground(new Color(51, 153, 255));
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                priZaviraniOkna(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- labMic ----
        labMic.setIcon(new ImageIcon(getClass().getResource("/net/sevecek/mic.png")));
        labMic.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                priStiskuMysiNaMic(e);
            }
        });
        contentPane.add(labMic);
        labMic.setBounds(new Rectangle(new Point(235, 175), labMic.getPreferredSize()));

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(545, 440);
        setLocationRelativeTo(null);

        //---- casovac ----
        casovac.setDelay(25);
        casovac.setInitialDelay(25);
        casovac.addActionListener(e -> priTiknutiCasovace(e));
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
