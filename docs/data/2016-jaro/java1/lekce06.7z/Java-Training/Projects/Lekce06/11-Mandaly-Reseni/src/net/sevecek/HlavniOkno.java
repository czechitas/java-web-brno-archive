package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import sun.awt.image.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel labObrazekMandaly;
    JLabel btnBarva1;
    JLabel btnBarva2;
    JLabel btnBarva3;
    JLabel btnBarva4;
    JLabel btnBarva5;
    JLabel labZvolenaBarva;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;
    Color barva;

    private void priStiskuBarvy(MouseEvent e) {
        JLabel tlacitko = (JLabel) e.getSource();
        barva = tlacitko.getBackground();
        labZvolenaBarva.setBackground(barva);
    }

    private void priKliknutiMysiNaMandalu(MouseEvent e) {
        int mysX = e.getX();
        int mysY = e.getY();
        vyplnObrazekVLabelu(mysX, mysY, barva, labObrazekMandaly);
    }

    public void vyplnObrazekVLabelu(Integer x, Integer y, Color barvaVyplne, JLabel label) {
        if (barvaVyplne == null) {
            barvaVyplne = new Color(255, 255, 0);
        }

        BufferedImage obrazek;
        ImageIcon icon = (ImageIcon) label.getIcon();
        Image puvodniImage = icon.getImage();
        if (puvodniImage instanceof BufferedImage) {
            obrazek = (BufferedImage) puvodniImage;
        } else if (puvodniImage instanceof ToolkitImage) {
            obrazek = ((ToolkitImage) puvodniImage).getBufferedImage();
        } else {
            obrazek = new BufferedImage(puvodniImage.getWidth(null), puvodniImage.getHeight(null), BufferedImage.TYPE_3BYTE_BGR);
            obrazek.getGraphics().drawImage(puvodniImage, 0, 0, null);
        }

        if (x < 0 || x >= obrazek.getWidth() || y < 0 || y >= obrazek.getHeight()) {
            return;
        }

        WritableRaster pixely = obrazek.getRaster();
        int[] novyPixel = new int[] {barvaVyplne.getRed(), barvaVyplne.getGreen(), barvaVyplne.getBlue(), barvaVyplne.getAlpha()};
        int[] staryPixel = new int[] {255, 255, 255, 255};
        staryPixel = pixely.getPixel(x, y, staryPixel);

        // Pokud uz je pocatecni pixel obarven na cilovou barvu, nic nemen
        if (isEqualRgb(novyPixel, staryPixel)) {
            return;
        }

        // Zamez prebarveni cerne cary
        int[] cernyPixel = new int[] {0, 0, 0, staryPixel[3]};
        if (isEqualRgb(cernyPixel, staryPixel)) {
            return;
        }

        floodLoop(pixely, x, y, novyPixel, staryPixel);

        ImageIcon obrazekJakoIkonka = new ImageIcon(obrazek);
        label.setIcon(obrazekJakoIkonka);
    }

    // Recursively fills surrounding pixels of the old color
    private void floodLoop(WritableRaster raster, int x, int y, int[] newColor, int[] originalColor) {
        Rectangle bounds = raster.getBounds();
        int[] currentColor = new int[] {255, 255, 255, 255};

        Deque<Point> stack = new ArrayDeque<>();
        stack.push(new Point(x, y));
        while (stack.size() > 0) {
            Point point = stack.pop();
            x = point.x;
            y = point.y;

            // finds the left side, filling along the way
            int fillL = x;
            do {
                raster.setPixel(fillL, y, newColor);
                fillL--;
            } while (fillL >= 0 && isEqualRgb(raster.getPixel(fillL, y, currentColor), originalColor));
            fillL++;

            // find the right right side, filling along the way
            int fillR = x;
            do {
                raster.setPixel(fillR, y, newColor);
                fillR++;
            }
            while (fillR < bounds.width - 1 && isEqualRgb(raster.getPixel(fillR, y, currentColor), originalColor));
            fillR--;

            // checks if applicable up or down
            for (int i = fillL; i <= fillR; i++) {
                if (y > 0 && isEqualRgb(raster.getPixel(i, y - 1, currentColor), originalColor)) {
                    stack.add(new Point(i, y - 1));
                }
                if (y < bounds.height - 1 && isEqualRgb(raster.getPixel(i, y + 1, currentColor), originalColor)) {
                    stack.add(new Point(i, y + 1));
                }
            }
        }
    }

    // Returns true if RGB arrays are equivalent, false otherwise
    private boolean isEqualRgb(int[] color1, int[] color2) {
        // Could use Arrays.equals(int[], int[]), but this is probably a little faster...
        return color1[0] == color2[0] && color1[1] == color2[1] && color1[2] == color2[2] && color1[3] == color2[3];
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        labObrazekMandaly = new JLabel();
        btnBarva1 = new JLabel();
        btnBarva2 = new JLabel();
        btnBarva3 = new JLabel();
        btnBarva4 = new JLabel();
        btnBarva5 = new JLabel();
        labZvolenaBarva = new JLabel();

        //======== this ========
        this.contentPane = getContentPane();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Mandaly");
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- labObrazekMandaly ----
        labObrazekMandaly.setIcon(new ImageIcon(getClass().getResource("/mandaly/mandala1.png")));
        labObrazekMandaly.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priKliknutiMysiNaMandalu(e);
            }
        });
        contentPane.add(labObrazekMandaly);
        labObrazekMandaly.setBounds(new Rectangle(new Point(0, 0), labObrazekMandaly.getPreferredSize()));

        //---- btnBarva1 ----
        btnBarva1.setBackground(new Color(51, 51, 255));
        btnBarva1.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva1.setOpaque(true);
        btnBarva1.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva1);
        btnBarva1.setBounds(650, 10, 40, 40);

        //---- btnBarva2 ----
        btnBarva2.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva2.setOpaque(true);
        btnBarva2.setBackground(new Color(255, 0, 51));
        btnBarva2.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva2);
        btnBarva2.setBounds(650, 60, 40, 40);

        //---- btnBarva3 ----
        btnBarva3.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva3.setBackground(Color.yellow);
        btnBarva3.setOpaque(true);
        btnBarva3.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva3);
        btnBarva3.setBounds(650, 110, 40, 40);

        //---- btnBarva4 ----
        btnBarva4.setOpaque(true);
        btnBarva4.setBackground(Color.green);
        btnBarva4.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva4.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva4);
        btnBarva4.setBounds(650, 160, 40, 40);

        //---- btnBarva5 ----
        btnBarva5.setBackground(new Color(153, 153, 255));
        btnBarva5.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva5.setOpaque(true);
        btnBarva5.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva5);
        btnBarva5.setBounds(650, 210, 40, 40);

        //---- labZvolenaBarva ----
        labZvolenaBarva.setText("barva");
        labZvolenaBarva.setHorizontalAlignment(SwingConstants.CENTER);
        labZvolenaBarva.setOpaque(true);
        labZvolenaBarva.setBorder(new BevelBorder(BevelBorder.LOWERED));
        contentPane.add(labZvolenaBarva);
        labZvolenaBarva.setBounds(650, 280, 40, 105);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(715, 675);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
