package net.sevecek.angrybirds.engine;

public abstract class AbstractCommand {

    protected abstract void execute();

}
