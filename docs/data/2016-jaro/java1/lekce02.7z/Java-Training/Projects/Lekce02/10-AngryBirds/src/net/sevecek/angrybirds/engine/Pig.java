package net.sevecek.angrybirds.engine;

public class Pig extends GenericTile {

    public Pig(GameBoard gameBoard) {
        super(gameBoard, "Pig.png");
    }
}
