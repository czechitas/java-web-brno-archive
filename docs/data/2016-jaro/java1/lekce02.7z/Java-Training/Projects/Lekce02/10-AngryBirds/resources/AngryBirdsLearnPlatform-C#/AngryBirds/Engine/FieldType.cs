namespace AngryBirds.Engine
{
    public enum FieldType
    {
        AngryBird = 0,
        Pig = 1,
        Obstacle = 2,
        Path = 3,
    }
}