using System;

namespace AngryBirds.Properties
{
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class AspMethodPropertyAttribute : Attribute { }
}