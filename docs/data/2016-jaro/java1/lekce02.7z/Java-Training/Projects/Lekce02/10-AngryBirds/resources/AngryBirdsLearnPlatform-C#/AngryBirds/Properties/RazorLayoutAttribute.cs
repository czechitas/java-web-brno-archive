using System;

namespace AngryBirds.Properties
{
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class RazorLayoutAttribute : Attribute { }
}