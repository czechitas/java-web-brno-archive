package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import sun.awt.image.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - Kurz Czechitas
    JLabel btnBarva1;
    JLabel btnBarva2;
    JLabel btnBarva3;
    JLabel btnBarva4;
    JLabel btnBarva5;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;
    Color barva;

    private void priStiskuBarvy(MouseEvent e) {
        JLabel tlacitko = (JLabel) e.getSource();
        barva = tlacitko.getBackground();
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - Kurz Czechitas
        btnBarva1 = new JLabel();
        btnBarva2 = new JLabel();
        btnBarva3 = new JLabel();
        btnBarva4 = new JLabel();
        btnBarva5 = new JLabel();

        //======== this ========
        this.contentPane = getContentPane();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Mandaly");
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- btnBarva1 ----
        btnBarva1.setBackground(new Color(51, 51, 255));
        btnBarva1.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva1.setOpaque(true);
        btnBarva1.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva1);
        btnBarva1.setBounds(650, 10, 40, 40);

        //---- btnBarva2 ----
        btnBarva2.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva2.setOpaque(true);
        btnBarva2.setBackground(new Color(255, 0, 51));
        btnBarva2.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva2);
        btnBarva2.setBounds(650, 60, 40, 40);

        //---- btnBarva3 ----
        btnBarva3.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva3.setBackground(Color.yellow);
        btnBarva3.setOpaque(true);
        btnBarva3.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva3);
        btnBarva3.setBounds(650, 110, 40, 40);

        //---- btnBarva4 ----
        btnBarva4.setOpaque(true);
        btnBarva4.setBackground(Color.green);
        btnBarva4.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva4.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva4);
        btnBarva4.setBounds(650, 160, 40, 40);

        //---- btnBarva5 ----
        btnBarva5.setBackground(new Color(153, 153, 255));
        btnBarva5.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva5.setOpaque(true);
        btnBarva5.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy(e);
            }
        });
        contentPane.add(btnBarva5);
        btnBarva5.setBounds(650, 210, 40, 40);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(715, 675);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
