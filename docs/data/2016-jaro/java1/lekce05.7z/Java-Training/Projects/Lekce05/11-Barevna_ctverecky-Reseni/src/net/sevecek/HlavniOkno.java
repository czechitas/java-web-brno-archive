package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.border.*;
import sun.awt.image.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - Kurz Czechitas
    JLabel btnBarva1;
    JLabel btnBarva2;
    JLabel btnBarva3;
    JLabel btnBarva4;
    JLabel btnBarva5;
    JTextField txtRGB;
    JLabel labSouradniceKliknuti;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;
    Color barva;

    private void priStiskuBarvy1(MouseEvent e) {
        zobrazSlozkyBarvy(btnBarva1);
    }

    private void priStiskuBarvy2(MouseEvent e) {
        zobrazSlozkyBarvy(btnBarva2);
    }

    private void priStiskuBarvy3(MouseEvent e) {
        zobrazSlozkyBarvy(btnBarva3);
    }

    private void priStiskuBarvy4(MouseEvent e) {
        zobrazSlozkyBarvy(btnBarva4);
    }

    private void priStiskuBarvy5(MouseEvent e) {
        zobrazSlozkyBarvy(btnBarva5);
    }

    private void zobrazSlozkyBarvy(JLabel tlacitko) {
        barva = tlacitko.getBackground();
        txtRGB.setBackground(barva);

        Integer cervena = barva.getRed();
        Integer zelena = barva.getGreen();
        Integer modra = barva.getBlue();
        String text = "Slozky barvy: " + cervena.toString() + ", " + zelena.toString() + ", " + modra.toString();
        txtRGB.setText(text);
    }

    private void priStiskuMysiNadObrazkem(MouseEvent e) {
        Integer x = e.getX();
        Integer y = e.getY();
        String text = "Kliknuto na souřadnicích " + x.toString() + ", " + y.toString();
        labSouradniceKliknuti.setText(text);
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - Kurz Czechitas
        btnBarva1 = new JLabel();
        btnBarva2 = new JLabel();
        btnBarva3 = new JLabel();
        btnBarva4 = new JLabel();
        btnBarva5 = new JLabel();
        txtRGB = new JTextField();
        labSouradniceKliknuti = new JLabel();

        //======== this ========
        this.contentPane = getContentPane();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Barevn\u00e9 \u010dtvere\u010dky");
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- btnBarva1 ----
        btnBarva1.setBackground(new Color(51, 51, 255));
        btnBarva1.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva1.setOpaque(true);
        btnBarva1.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy1(e);
            }
        });
        contentPane.add(btnBarva1);
        btnBarva1.setBounds(10, 10, 40, 40);

        //---- btnBarva2 ----
        btnBarva2.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva2.setOpaque(true);
        btnBarva2.setBackground(new Color(255, 0, 51));
        btnBarva2.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy2(e);
            }
        });
        contentPane.add(btnBarva2);
        btnBarva2.setBounds(10, 60, 40, 40);

        //---- btnBarva3 ----
        btnBarva3.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva3.setBackground(Color.yellow);
        btnBarva3.setOpaque(true);
        btnBarva3.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy3(e);
            }
        });
        contentPane.add(btnBarva3);
        btnBarva3.setBounds(10, 110, 40, 40);

        //---- btnBarva4 ----
        btnBarva4.setOpaque(true);
        btnBarva4.setBackground(Color.green);
        btnBarva4.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva4.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy4(e);
            }
        });
        contentPane.add(btnBarva4);
        btnBarva4.setBounds(10, 160, 40, 40);

        //---- btnBarva5 ----
        btnBarva5.setBackground(new Color(153, 153, 255));
        btnBarva5.setBorder(new BevelBorder(BevelBorder.RAISED));
        btnBarva5.setOpaque(true);
        btnBarva5.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuBarvy5(e);
            }
        });
        contentPane.add(btnBarva5);
        btnBarva5.setBounds(10, 210, 40, 40);

        //---- txtRGB ----
        txtRGB.setEditable(false);
        txtRGB.setHorizontalAlignment(SwingConstants.CENTER);
        txtRGB.setFont(txtRGB.getFont().deriveFont(txtRGB.getFont().getSize() + 9f));
        contentPane.add(txtRGB);
        txtRGB.setBounds(110, 35, 410, 65);

        //---- labSouradniceKliknuti ----
        labSouradniceKliknuti.setText("Klikn\u011bte sem");
        labSouradniceKliknuti.setHorizontalAlignment(SwingConstants.CENTER);
        labSouradniceKliknuti.setBackground(new Color(204, 255, 255));
        labSouradniceKliknuti.setOpaque(true);
        labSouradniceKliknuti.setBorder(new BevelBorder(BevelBorder.LOWERED));
        labSouradniceKliknuti.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                priStiskuMysiNadObrazkem(e);
            }
        });
        contentPane.add(labSouradniceKliknuti);
        labSouradniceKliknuti.setBounds(110, 160, 410, 60);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(590, 295);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
