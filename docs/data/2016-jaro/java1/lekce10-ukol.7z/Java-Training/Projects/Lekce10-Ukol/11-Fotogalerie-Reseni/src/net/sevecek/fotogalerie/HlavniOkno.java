package net.sevecek.fotogalerie;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JButton btnPredchozi;
    JButton btnDalsi;
    JLabel labCesta;
    JTextField txtCesta;
    JButton btnProchazet;
    JButton btnSpustit;
    JLabel labObrazek;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;
    List<String> obrazky;
    Integer cisloAktualnihoObrazku;

    private void priStiskuBtnProchazet(ActionEvent e) {
        JFileChooser oknoVyber = new JFileChooser();
        oknoVyber.setCurrentDirectory(new File("."));
        oknoVyber.setDialogTitle("Vyberte zložku s obrázky");
        oknoVyber.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        oknoVyber.setAcceptAllFileFilterUsed(false);

        if (oknoVyber.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            String cesta = oknoVyber.getSelectedFile().getAbsolutePath();
            txtCesta.setText(cesta);
        }
    }

    private void priStiskuBtnSpustit(ActionEvent e) {
        String cesta = txtCesta.getText();
        File slozka = new File(cesta);
        File[] soubory = slozka.listFiles();
        if (soubory == null) {
            return;
        }

        obrazky = new ArrayList<>();
        for (File soubor : soubory) {
            if (soubor.isFile()) {
                if (soubor.getName().toLowerCase().endsWith(".jpg")
                        || soubor.getName().toLowerCase().endsWith(".png")) {
                    String jmenoSouboru = soubor.getAbsolutePath();
                    obrazky.add(jmenoSouboru);
                }
            }
        }
        cisloAktualnihoObrazku = 0;

        labCesta.setVisible(false);
        txtCesta.setVisible(false);
        btnProchazet.setVisible(false);
        btnSpustit.setVisible(false);
        btnPredchozi.setVisible(true);
        btnDalsi.setVisible(true);
        zobrazObrazek();
    }

    private void zobrazObrazek() {
        String souborSObrazkem = obrazky.get(cisloAktualniObrazku);
        ImageIcon obrazek = new ImageIcon(souborSObrazkem);
        labObrazek.setIcon(obrazek);
    }

    private void priStiskuBtnPredchozi(ActionEvent e) {
        if (cisloAktualniObrazku > 0) {
            cisloAktualniObrazku--;
        }
        zobrazObrazek();
    }

    private void priStiskuBtnDalsi(ActionEvent e) {
        if (cisloAktualniObrazku < obrazky.size() - 1) {
            cisloAktualniObrazku++;
        }
        zobrazObrazek();
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        btnPredchozi = new JButton();
        btnDalsi = new JButton();
        labCesta = new JLabel();
        txtCesta = new JTextField();
        btnProchazet = new JButton();
        btnSpustit = new JButton();
        labObrazek = new JLabel();

        //======== this ========
        this.contentPane = this.getContentPane();
        this.contentPane.setBackground(Color.WHITE);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Fotogalerie");
        setResizable(false);
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- btnPredchozi ----
        btnPredchozi.setText("<");
        btnPredchozi.setFont(btnPredchozi.getFont().deriveFont(btnPredchozi.getFont().getStyle() | Font.BOLD, btnPredchozi.getFont().getSize() + 5f));
        btnPredchozi.setVisible(false);
        btnPredchozi.addActionListener(e -> priStiskuBtnPredchozi(e));
        contentPane.add(btnPredchozi);
        btnPredchozi.setBounds(new Rectangle(new Point(10, 240), btnPredchozi.getPreferredSize()));

        //---- btnDalsi ----
        btnDalsi.setText(">");
        btnDalsi.setFont(btnDalsi.getFont().deriveFont(btnDalsi.getFont().getStyle() | Font.BOLD, btnDalsi.getFont().getSize() + 5f));
        btnDalsi.setVisible(false);
        btnDalsi.addActionListener(e -> priStiskuBtnDalsi(e));
        contentPane.add(btnDalsi);
        btnDalsi.setBounds(new Rectangle(new Point(720, 240), btnDalsi.getPreferredSize()));

        //---- labCesta ----
        labCesta.setText("Cesta k obr\u00e1zk\u016fm:");
        labCesta.setFont(labCesta.getFont().deriveFont(labCesta.getFont().getSize() + 3f));
        contentPane.add(labCesta);
        labCesta.setBounds(new Rectangle(new Point(5, 10), labCesta.getPreferredSize()));

        //---- txtCesta ----
        txtCesta.setText("src\\obrazky");
        txtCesta.setFont(txtCesta.getFont().deriveFont(txtCesta.getFont().getStyle() | Font.BOLD, txtCesta.getFont().getSize() + 3f));
        contentPane.add(txtCesta);
        txtCesta.setBounds(150, 6, 500, txtCesta.getPreferredSize().height);

        //---- btnProchazet ----
        btnProchazet.setText("Proch\u00e1zet...");
        btnProchazet.setFont(btnProchazet.getFont().deriveFont(btnProchazet.getFont().getSize() + 3f));
        btnProchazet.addActionListener(e -> priStiskuBtnProchazet(e));
        contentPane.add(btnProchazet);
        btnProchazet.setBounds(new Rectangle(new Point(660, 5), btnProchazet.getPreferredSize()));

        //---- btnSpustit ----
        btnSpustit.setText("Nahr\u00e1t obr\u00e1zky");
        btnSpustit.setFont(btnSpustit.getFont().deriveFont(btnSpustit.getFont().getStyle() | Font.BOLD, btnSpustit.getFont().getSize() + 3f));
        btnSpustit.addActionListener(e -> priStiskuBtnSpustit(e));
        contentPane.add(btnSpustit);
        btnSpustit.setBounds(new Rectangle(new Point(315, 40), btnSpustit.getPreferredSize()));

        //---- labObrazek ----
        labObrazek.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(labObrazek);
        labObrazek.setBounds(60, 10, 665, 520);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(790, 580);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
