package net.sevecek.objekty;

public class Clovek {

    String jmeno;
    Clovek partner;

}
