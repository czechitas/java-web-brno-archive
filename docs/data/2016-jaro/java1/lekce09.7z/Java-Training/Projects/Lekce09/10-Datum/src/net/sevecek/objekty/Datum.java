package net.sevecek.objekty;

public class Datum {

    Integer den;
    Integer mesic;
    Integer rok;

}
