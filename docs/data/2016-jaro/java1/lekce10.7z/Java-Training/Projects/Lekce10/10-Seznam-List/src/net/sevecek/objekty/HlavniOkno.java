package net.sevecek.objekty;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import net.sevecek.util.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel label1;
    JLabel label2;
    JLabel label3;
    JLabel label4;
    JButton button1;
    Random generatorNahodnychCisel;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;

    private void priStiskuTlacitka(ActionEvent e) {
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        label1 = new JLabel();
        label2 = new JLabel();
        label3 = new JLabel();
        label4 = new JLabel();
        button1 = new JButton();
        generatorNahodnychCisel = new Random();

        //======== this ========
        this.contentPane = this.getContentPane();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Objekty");
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- label1 ----
        label1.setText("label1");
        label1.setFont(label1.getFont().deriveFont(label1.getFont().getStyle() | Font.BOLD, label1.getFont().getSize() + 7f));
        contentPane.add(label1);
        label1.setBounds(15, 15, 430, label1.getPreferredSize().height);

        //---- label2 ----
        label2.setText("label2");
        label2.setFont(label2.getFont().deriveFont(label2.getFont().getStyle() | Font.BOLD, label2.getFont().getSize() + 7f));
        contentPane.add(label2);
        label2.setBounds(15, 45, 430, 22);

        //---- label3 ----
        label3.setFont(label3.getFont().deriveFont(label3.getFont().getStyle() | Font.BOLD, label3.getFont().getSize() + 7f));
        contentPane.add(label3);
        label3.setBounds(15, 75, 430, 22);

        //---- label4 ----
        label4.setFont(label4.getFont().deriveFont(label4.getFont().getStyle() | Font.BOLD, label4.getFont().getSize() + 7f));
        contentPane.add(label4);
        label4.setBounds(15, 105, 430, 22);

        //---- button1 ----
        button1.setText("Spust test");
        button1.setFont(button1.getFont().deriveFont(button1.getFont().getSize() + 5f));
        button1.addActionListener(e -> priStiskuTlacitka(e));
        contentPane.add(button1);
        button1.setBounds(new Rectangle(new Point(175, 160), button1.getPreferredSize()));

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(475, 235);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
