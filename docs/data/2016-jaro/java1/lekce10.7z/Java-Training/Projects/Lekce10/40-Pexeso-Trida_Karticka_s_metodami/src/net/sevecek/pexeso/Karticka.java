package net.sevecek.pexeso;

import java.awt.*;
import javax.swing.*;

public class Karticka {

    Integer cisloKarty;     // 0..63
    Integer cisloObrazku;   // 0..31
    Integer poziceX;        // 0..7
    Integer poziceY;        // 0..7
    Boolean jeLicemNahoru;
    ImageIcon obrazekLice;
    ImageIcon obrazekRubu;
    JButton btnKarticka;

    public Karticka(Container contentPane, Integer cisloKarticky) {
        cisloKarty = cisloKarticky;
        cisloObrazku = cisloKarty / 2;
        obrazekLice = new ImageIcon(getClass().getClassLoader().getResource("net/sevecek/pexeso/obrazky/" + cisloObrazku + ".jpg"));
        obrazekRubu = new ImageIcon(getClass().getClassLoader().getResource("net/sevecek/pexeso/obrazky/rub.png"));
        btnKarticka = new JButton();
        btnKarticka.setSize(90, 90);
        contentPane.add(btnKarticka);
        setLicemNahoru(true);
    }

    public void setLicemNahoru(Boolean hodnota) {
        jeLicemNahoru = hodnota;
        if (hodnota) {
            btnKarticka.setIcon(obrazekLice);
        } else {
            btnKarticka.setIcon(obrazekRubu);
        }
    }

    public void setPozice(Integer x, Integer y) {
        poziceX = x;
        poziceY = y;
        btnKarticka.setLocation(10 + x * 100, 10 + y * 100);
    }

    public void vymenSiPoziciSKartou(Karticka karta2) {
        Point poziceKarty1 = this.btnKarticka.getLocation();
        Point poziceKarty2 = karta2.btnKarticka.getLocation();
        this.btnKarticka.setLocation(poziceKarty2);
        karta2.btnKarticka.setLocation(poziceKarty1);
    }
}
