package net.sevecek.pexeso;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JButton btnZamichat;
    Random generatorNahodnychCisel;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;
    List<Karticka> seznamKaret;

    private void priOtevreniOkna(WindowEvent e) {
        seznamKaret = new ArrayList<>();
        Integer cisloKarticky = 0;
        for (Integer y = 0; y < 8; y++) {
            for (Integer x = 0; x < 8; x++) {
                Karticka novaKarta = new Karticka(contentPane, cisloKarticky);
                novaKarta.setPozice(x, y);
                seznamKaret.add(novaKarta);
                cisloKarticky++;
            }
        }
    }

    private void priStiskuBtnZamichat(ActionEvent e) {
        for (Integer i = 0; i < 1000; i++) {
            Integer cisloKarty1 = generatorNahodnychCisel.nextInt(64);
            Integer cisloKarty2 = generatorNahodnychCisel.nextInt(64);

            Karticka karta1 = seznamKaret.get(cisloKarty1);
            Karticka karta2 = seznamKaret.get(cisloKarty2);
            seznamKaret.set(cisloKarty2, karta1);
            seznamKaret.set(cisloKarty1, karta2);

            karta1.vymenSiPoziciSKartou(karta2);
        }
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        btnZamichat = new JButton();
        generatorNahodnychCisel = new Random();

        //======== this ========
        this.contentPane = this.getContentPane();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Pexeso");
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                priOtevreniOkna(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- btnZamichat ----
        btnZamichat.setText("Zam\u00edchat");
        btnZamichat.setFont(btnZamichat.getFont().deriveFont(btnZamichat.getFont().getStyle() | Font.BOLD, btnZamichat.getFont().getSize() + 5f));
        btnZamichat.addActionListener(e -> priStiskuBtnZamichat(e));
        contentPane.add(btnZamichat);
        btnZamichat.setBounds(new Rectangle(new Point(350, 0), btnZamichat.getPreferredSize()));

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(825, 850);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
