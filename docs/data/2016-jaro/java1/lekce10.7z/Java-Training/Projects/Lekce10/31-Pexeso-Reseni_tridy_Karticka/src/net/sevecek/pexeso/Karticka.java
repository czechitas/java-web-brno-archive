package net.sevecek.pexeso;

import javax.swing.*;

public class Karticka {

    Integer cisloKarty;     // 0..63
    Integer cisloObrazku;   // 0..31
    Integer poziceX;        // 0..7
    Integer poziceY;        // 0..7
    Boolean jeLicemNahoru;
    ImageIcon obrazekLice;
    ImageIcon obrazekRubu;
    JButton btnKarticka;


}
