package net.sevecek.pexeso;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JButton btnZamichat;
    Random generatorNahodnychCisel;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Container contentPane;
    List<JButton> seznamKaret;

    private void priOtevreniOkna(WindowEvent e) {
        seznamKaret = new ArrayList<>();
        for (Integer k = 0; k < 8; k++) {
            for (Integer j = 0; j < 2; j++) {
                for (Integer i = 0; i < 4; i++) {
                    ImageIcon obrazek = new ImageIcon(getClass().getClassLoader().getResource("net/sevecek/pexeso/obrazky/" + (i+k*4) + ".jpg"));
                    JButton btnKarticka = new JButton();
                    btnKarticka.setIcon(obrazek);
                    btnKarticka.setSize(90, 90);
                    contentPane.add(btnKarticka);
                    btnKarticka.setLocation(i * 100 + j * 400 + 10, k * 100 + 10);
                    seznamKaret.add(btnKarticka);
                }
            }
        }
    }

    private void priStiskuBtnZamichat(ActionEvent e) {
        for (Integer i = 0; i<1000; i++) {
            Integer cisloKarty1 = generatorNahodnychCisel.nextInt(64);
            Integer cisloKarty2 = generatorNahodnychCisel.nextInt(64);

            JButton karta1 = seznamKaret.get(cisloKarty1);
            JButton karta2 = seznamKaret.get(cisloKarty2);
            seznamKaret.set(cisloKarty2, karta1);
            seznamKaret.set(cisloKarty1, karta2);

            Point poziceKarty1 = karta1.getLocation();
            Point poziceKarty2 = karta2.getLocation();
            karta1.setLocation(poziceKarty2);
            karta2.setLocation(poziceKarty1);
        }
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        btnZamichat = new JButton();
        generatorNahodnychCisel = new Random();

        //======== this ========
        this.contentPane = this.getContentPane();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Pexeso");
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                priOtevreniOkna(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- btnZamichat ----
        btnZamichat.setText("Zam\u00edchat");
        btnZamichat.setFont(btnZamichat.getFont().deriveFont(btnZamichat.getFont().getStyle() | Font.BOLD, btnZamichat.getFont().getSize() + 5f));
        btnZamichat.addActionListener(e -> priStiskuBtnZamichat(e));
        contentPane.add(btnZamichat);
        btnZamichat.setBounds(new Rectangle(new Point(350, 0), btnZamichat.getPreferredSize()));

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(825, 850);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
