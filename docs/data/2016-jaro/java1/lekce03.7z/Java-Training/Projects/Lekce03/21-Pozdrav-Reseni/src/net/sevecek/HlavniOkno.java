package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - Kurz Czechitas
    JLabel labJmeno;
    JTextField txtJmeno;
    JButton btnPozdravit;
    JLabel labPozdrav;
    // JFormDesigner - End of variables declaration  //GEN-END:variables


    private void poStiskuPozdravit(ActionEvent e) {
        String jmeno = txtJmeno.getText();
        String pozdrav = jmeno + " zdraví z Javy";
        labPozdrav.setText(pozdrav);
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - Kurz Czechitas
        labJmeno = new JLabel();
        txtJmeno = new JTextField();
        btnPozdravit = new JButton();
        labPozdrav = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Czechitas");
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- labJmeno ----
        labJmeno.setText("Zadejte svoje jm\u00e9no:");
        labJmeno.setFont(labJmeno.getFont().deriveFont(labJmeno.getFont().getSize() + 3f));
        contentPane.add(labJmeno);
        labJmeno.setBounds(new Rectangle(new Point(20, 20), labJmeno.getPreferredSize()));

        //---- txtJmeno ----
        txtJmeno.setFont(txtJmeno.getFont().deriveFont(txtJmeno.getFont().getSize() + 3f));
        contentPane.add(txtJmeno);
        txtJmeno.setBounds(170, 12, 260, 36);

        //---- btnPozdravit ----
        btnPozdravit.setText("Pozdravit!");
        btnPozdravit.setFont(btnPozdravit.getFont().deriveFont(btnPozdravit.getFont().getSize() + 3f));
        btnPozdravit.addActionListener(e -> poStiskuPozdravit(e));
        this.getRootPane().setDefaultButton(btnPozdravit);
        contentPane.add(btnPozdravit);
        btnPozdravit.setBounds(new Rectangle(new Point(445, 15), btnPozdravit.getPreferredSize()));

        //---- labPozdrav ----
        labPozdrav.setFont(labPozdrav.getFont().deriveFont(labPozdrav.getFont().getStyle() | Font.BOLD, labPozdrav.getFont().getSize() + 4f));
        labPozdrav.setHorizontalAlignment(SwingConstants.CENTER);
        labPozdrav.setBorder(new SoftBevelBorder(SoftBevelBorder.LOWERED));
        contentPane.add(labPozdrav);
        labPozdrav.setBounds(60, 80, 445, 55);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(585, 190);
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
