package net.sevecek;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - Kurz Czechitas
    JLabel labPocetHus;
    JLabel labPocetKraliku;
    JTextField txtPocetHus;
    JTextField txtPocetKraliku;
    JButton btnVypocitat;
    JLabel labPocetNohou;
    JLabel labPocetHlav;
    JTextField txtPocetNohou;
    JTextField txtPocetHlav;
    // JFormDesigner - End of variables declaration  //GEN-END:variables


    private void poStiskuVypocitat(ActionEvent e) {
        String pocetHusString = txtPocetHus.getText();
        Integer pocetHus = new Integer(pocetHusString);
        String pocetKralikuString = txtPocetKraliku.getText();
        Integer pocetKraliku = new Integer(pocetKralikuString);

        Integer pocetHlav = pocetHus + pocetKraliku;
        Integer pocetNohou = pocetHus * 2 + pocetKraliku * 4;

        String pocetHlavString = pocetHlav.toString();
        String pocetNohouString = pocetNohou.toString();
        txtPocetHlav.setText(pocetHlavString);
        txtPocetNohou.setText(pocetNohouString);
    }

    public void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - Kurz Czechitas
        labPocetHus = new JLabel();
        labPocetKraliku = new JLabel();
        txtPocetHus = new JTextField();
        txtPocetKraliku = new JTextField();
        btnVypocitat = new JButton();
        labPocetNohou = new JLabel();
        labPocetHlav = new JLabel();
        txtPocetNohou = new JTextField();
        txtPocetHlav = new JTextField();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Husy a kr\u00e1l\u00edc\u00ed");
        Container contentPane = getContentPane();
        contentPane.setLayout(null);

        //---- labPocetHus ----
        labPocetHus.setText("Po\u010det hus:");
        contentPane.add(labPocetHus);
        labPocetHus.setBounds(new Rectangle(new Point(20, 20), labPocetHus.getPreferredSize()));

        //---- labPocetKraliku ----
        labPocetKraliku.setText("Po\u010det kr\u00e1l\u00edk\u016f:");
        contentPane.add(labPocetKraliku);
        labPocetKraliku.setBounds(new Rectangle(new Point(20, 50), labPocetKraliku.getPreferredSize()));
        contentPane.add(txtPocetHus);
        txtPocetHus.setBounds(100, 15, 185, txtPocetHus.getPreferredSize().height);
        contentPane.add(txtPocetKraliku);
        txtPocetKraliku.setBounds(100, 45, 185, txtPocetKraliku.getPreferredSize().height);

        //---- btnVypocitat ----
        btnVypocitat.setText("Vypo\u010d\u00edtat");
        btnVypocitat.addActionListener(e -> poStiskuVypocitat(e));
        this.getRootPane().setDefaultButton(btnVypocitat);
        contentPane.add(btnVypocitat);
        btnVypocitat.setBounds(100, 80, 115, btnVypocitat.getPreferredSize().height);

        //---- labPocetNohou ----
        labPocetNohou.setText("Po\u010det nohou:");
        contentPane.add(labPocetNohou);
        labPocetNohou.setBounds(new Rectangle(new Point(20, 125), labPocetNohou.getPreferredSize()));

        //---- labPocetHlav ----
        labPocetHlav.setText("Po\u010det hlav:");
        contentPane.add(labPocetHlav);
        labPocetHlav.setBounds(new Rectangle(new Point(20, 150), labPocetHlav.getPreferredSize()));

        //---- txtPocetNohou ----
        txtPocetNohou.setEditable(false);
        txtPocetNohou.setBackground(UIManager.getColor("TextField.inactiveBackground"));
        contentPane.add(txtPocetNohou);
        txtPocetNohou.setBounds(100, 120, 185, txtPocetNohou.getPreferredSize().height);

        //---- txtPocetHlav ----
        txtPocetHlav.setEditable(false);
        txtPocetHlav.setBackground(UIManager.getColor("TextField.inactiveBackground"));
        contentPane.add(txtPocetHlav);
        txtPocetHlav.setBounds(100, 145, 185, txtPocetHlav.getPreferredSize().height);

        { // compute preferred size
            Dimension preferredSize = new Dimension();
            for(int i = 0; i < contentPane.getComponentCount(); i++) {
                Rectangle bounds = contentPane.getComponent(i).getBounds();
                preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
                preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
            }
            Insets insets = contentPane.getInsets();
            preferredSize.width += insets.right;
            preferredSize.height += insets.bottom;
            contentPane.setMinimumSize(preferredSize);
            contentPane.setPreferredSize(preferredSize);
        }
        setSize(320, 220);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
