package cz.czechitas.recept.naradi;

public class ElektrickaTrouba {

    public void zapniSe(int naJakouTeplotu) {
    }


    public void vlozSiDovnitr(PlechNaPeceni kteryPlech) {
    }


    public void pec(int kolikMinut) {
    }


    public void vypniSe() {
    }


    public void vyndejObsahVen() {
    }
}
