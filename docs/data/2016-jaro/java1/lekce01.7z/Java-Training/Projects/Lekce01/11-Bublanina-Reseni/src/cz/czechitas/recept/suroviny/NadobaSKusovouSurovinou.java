package cz.czechitas.recept.suroviny;

public interface NadobaSKusovouSurovinou {

}
