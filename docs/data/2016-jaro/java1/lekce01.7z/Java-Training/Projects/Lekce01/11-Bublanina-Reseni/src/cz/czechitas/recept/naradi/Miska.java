package cz.czechitas.recept.naradi;

import cz.czechitas.recept.suroviny.*;

public class Miska implements NadobaSeSypkouSurovinou {

    public void nalozJedenKus(NadobaSKusovouSurovinou ceho) {
    }


    public void nalozCelyObsah(NadobaSeSypkouSurovinou ceho) {
    }


    public void nalozTrochu(NadobaSeSypkouSurovinou ceho) {
    }


    public void vylozTrochu() {
    }
}
