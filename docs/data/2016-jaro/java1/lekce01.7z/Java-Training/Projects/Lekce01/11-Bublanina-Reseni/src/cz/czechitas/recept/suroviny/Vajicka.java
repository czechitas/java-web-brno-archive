package cz.czechitas.recept.suroviny;

public class Vajicka implements NadobaSKusovouSurovinou {

}
