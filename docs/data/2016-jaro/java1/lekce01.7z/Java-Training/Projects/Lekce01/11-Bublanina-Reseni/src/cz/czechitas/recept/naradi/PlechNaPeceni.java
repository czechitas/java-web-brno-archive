package cz.czechitas.recept.naradi;

import cz.czechitas.recept.suroviny.*;

public class PlechNaPeceni {

    public void nalozJedenKus(NadobaSKusovouSurovinou ceho) {
    }


    public void nalozCelyObsah(Miska zKtereMisky) {
    }
}
