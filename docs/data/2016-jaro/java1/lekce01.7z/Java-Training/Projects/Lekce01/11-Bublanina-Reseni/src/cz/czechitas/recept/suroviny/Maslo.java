package cz.czechitas.recept.suroviny;

public class Maslo implements NadobaSKusovouSurovinou {

}
