package cz.czechitas.recept.suroviny;

public class Mouka implements NadobaSeSypkouSurovinou {

}
