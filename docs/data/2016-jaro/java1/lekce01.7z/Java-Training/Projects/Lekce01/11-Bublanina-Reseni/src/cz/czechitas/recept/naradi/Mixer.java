package cz.czechitas.recept.naradi;

public class Mixer {

    public void zamichej(Miska kterouMisku) {
    }
}
