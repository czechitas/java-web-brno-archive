package cz.czechitas.recept.suroviny;

public class Ovoce implements NadobaSKusovouSurovinou {

}
