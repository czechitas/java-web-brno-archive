package cz.czechitas.recept;

import cz.czechitas.recept.naradi.*;
import cz.czechitas.recept.suroviny.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        Miska cervenaMiska = new Miska();
        Miska zlutaMiska = new Miska();
        Mixer mixer = new Mixer();
        KuchynskaVaha vaha = new KuchynskaVaha();
        PlechNaPeceni plech = new PlechNaPeceni();
        ElektrickaTrouba trouba = new ElektrickaTrouba();

        Vajicka platoVajec = new Vajicka();
        Cukr pytlikCukru = new Cukr();
        Mouka pytlikMouky = new Mouka();
        Maslo maslo125g = new Maslo();
        PrasekDoPeciva prasekDoPeciva = new PrasekDoPeciva();
        Ovoce kosikOvoce = new Ovoce();

        //---------------------------------------------------------------------

        // TODO: Sem napiste recept na bublaninu
    }

}
