package cz.czechitas.recept.naradi;

public class KuchynskaVaha {

    public int zjistiHmotnost(Miska ktereMisky) {
        return (int) (Math.random() * 500.0);
    }
}
