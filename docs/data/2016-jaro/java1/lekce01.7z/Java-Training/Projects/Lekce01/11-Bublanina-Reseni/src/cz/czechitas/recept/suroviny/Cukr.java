package cz.czechitas.recept.suroviny;

public class Cukr implements NadobaSeSypkouSurovinou {

}
