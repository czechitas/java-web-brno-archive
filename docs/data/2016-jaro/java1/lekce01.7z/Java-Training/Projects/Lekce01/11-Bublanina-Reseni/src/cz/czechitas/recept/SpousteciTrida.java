package cz.czechitas.recept;

import cz.czechitas.recept.naradi.*;
import cz.czechitas.recept.suroviny.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        Miska cervenaMiska = new Miska();
        Miska zlutaMiska = new Miska();
        Mixer mixer = new Mixer();
        KuchynskaVaha vaha = new KuchynskaVaha();
        PlechNaPeceni plech = new PlechNaPeceni();
        ElektrickaTrouba trouba = new ElektrickaTrouba();

        Vajicka platoVajec = new Vajicka();
        Cukr pytlikCukru = new Cukr();
        Mouka pytlikMouky = new Mouka();
        Maslo maslo125g = new Maslo();
        PrasekDoPeciva prasekDoPeciva = new PrasekDoPeciva();
        Ovoce kosikOvoce = new Ovoce();

        //---------------------------------------------------------------------

        for (int i=0; i<4; i++) {
            cervenaMiska.nalozJedenKus(platoVajec);
        }

        cervenaMiska.nalozCelyObsah(pytlikCukru);
        mixer.zamichej(cervenaMiska);

        zlutaMiska.nalozTrochu(pytlikMouky);
        while (vaha.zjistiHmotnost(zlutaMiska) != 250) {
            if (vaha.zjistiHmotnost(zlutaMiska) < 250) {
                zlutaMiska.vylozTrochu();
            }
            if (vaha.zjistiHmotnost(zlutaMiska) > 250) {
                zlutaMiska.nalozTrochu(pytlikMouky);
            }
        }
        cervenaMiska.nalozCelyObsah(zlutaMiska);

        cervenaMiska.nalozJedenKus(maslo125g);
        cervenaMiska.nalozCelyObsah(prasekDoPeciva);
        mixer.zamichej(cervenaMiska);

        plech.nalozCelyObsah(cervenaMiska);
        for (int i=0; i<50; i++) {
            plech.nalozJedenKus(kosikOvoce);
        }

        trouba.zapniSe(180);
        trouba.pec(5);
        trouba.vlozSiDovnitr(plech);
        trouba.pec(25);
        trouba.vypniSe();
        trouba.vyndejObsahVen();
    }

}
